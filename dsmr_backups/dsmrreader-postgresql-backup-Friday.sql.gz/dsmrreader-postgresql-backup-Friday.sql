--
-- PostgreSQL database dump
--

-- Dumped from database version 14.7
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO dsmrreader;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO dsmrreader;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO dsmrreader;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO dsmrreader;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO dsmrreader;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO dsmrreader;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO dsmrreader;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO dsmrreader;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.auth_user_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO dsmrreader;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.auth_user_groups_id_seq OWNED BY public.auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.auth_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO dsmrreader;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.auth_user_id_seq OWNED BY public.auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO dsmrreader;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.auth_user_user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO dsmrreader;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.auth_user_user_permissions_id_seq OWNED BY public.auth_user_user_permissions.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO dsmrreader;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO dsmrreader;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO dsmrreader;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO dsmrreader;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO dsmrreader;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO dsmrreader;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO dsmrreader;

--
-- Name: dsmr_api_apisettings; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_api_apisettings (
    id integer NOT NULL,
    allow boolean NOT NULL,
    auth_key character varying(256)
);


ALTER TABLE public.dsmr_api_apisettings OWNER TO dsmrreader;

--
-- Name: dsmr_api_apisettings_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_api_apisettings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_api_apisettings_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_api_apisettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_api_apisettings_id_seq OWNED BY public.dsmr_api_apisettings.id;


--
-- Name: dsmr_backend_backendsettings; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_backend_backendsettings (
    id integer NOT NULL,
    language character varying(32) NOT NULL,
    automatic_update_checker boolean NOT NULL,
    process_sleep numeric(4,1) NOT NULL,
    disable_electricity_returned_capability boolean NOT NULL,
    disable_gas_capability boolean NOT NULL,
    restart_required boolean NOT NULL
);


ALTER TABLE public.dsmr_backend_backendsettings OWNER TO dsmrreader;

--
-- Name: dsmr_backend_backendsettings_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_backend_backendsettings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_backend_backendsettings_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_backend_backendsettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_backend_backendsettings_id_seq OWNED BY public.dsmr_backend_backendsettings.id;


--
-- Name: dsmr_backend_emailsettings; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_backend_emailsettings (
    id integer NOT NULL,
    host character varying(255),
    port integer,
    username character varying(255),
    password character varying(255),
    use_tls boolean NOT NULL,
    use_ssl boolean NOT NULL,
    email_to character varying(255),
    email_from character varying(255)
);


ALTER TABLE public.dsmr_backend_emailsettings OWNER TO dsmrreader;

--
-- Name: dsmr_backend_emailsettings_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_backend_emailsettings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_backend_emailsettings_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_backend_emailsettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_backend_emailsettings_id_seq OWNED BY public.dsmr_backend_emailsettings.id;


--
-- Name: dsmr_backend_scheduledprocess; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_backend_scheduledprocess (
    id integer NOT NULL,
    name character varying(64) NOT NULL,
    module character varying(128) NOT NULL,
    planned timestamp with time zone NOT NULL,
    active boolean NOT NULL,
    last_executed_at timestamp with time zone
);


ALTER TABLE public.dsmr_backend_scheduledprocess OWNER TO dsmrreader;

--
-- Name: dsmr_backend_scheduledprocess_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_backend_scheduledprocess_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_backend_scheduledprocess_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_backend_scheduledprocess_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_backend_scheduledprocess_id_seq OWNED BY public.dsmr_backend_scheduledprocess.id;


--
-- Name: dsmr_backup_backupsettings; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_backup_backupsettings (
    id integer NOT NULL,
    daily_backup boolean NOT NULL,
    backup_time time without time zone NOT NULL,
    folder character varying(512) NOT NULL,
    compression_level integer NOT NULL,
    file_name character varying(96) NOT NULL,
    backup_interval_in_days integer NOT NULL
);


ALTER TABLE public.dsmr_backup_backupsettings OWNER TO dsmrreader;

--
-- Name: dsmr_backup_backupsettings_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_backup_backupsettings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_backup_backupsettings_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_backup_backupsettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_backup_backupsettings_id_seq OWNED BY public.dsmr_backup_backupsettings.id;


--
-- Name: dsmr_backup_dropboxsettings; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_backup_dropboxsettings (
    id integer NOT NULL,
    one_time_authorization_code character varying(255),
    refresh_token character varying(255),
    serialized_auth_flow bytea
);


ALTER TABLE public.dsmr_backup_dropboxsettings OWNER TO dsmrreader;

--
-- Name: dsmr_backup_dropboxsettings_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_backup_dropboxsettings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_backup_dropboxsettings_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_backup_dropboxsettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_backup_dropboxsettings_id_seq OWNED BY public.dsmr_backup_dropboxsettings.id;


--
-- Name: dsmr_backup_emailbackupsettings; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_backup_emailbackupsettings (
    id integer NOT NULL,
    "interval" integer
);


ALTER TABLE public.dsmr_backup_emailbackupsettings OWNER TO dsmrreader;

--
-- Name: dsmr_backup_emailbackupsettings_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_backup_emailbackupsettings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_backup_emailbackupsettings_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_backup_emailbackupsettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_backup_emailbackupsettings_id_seq OWNED BY public.dsmr_backup_emailbackupsettings.id;


--
-- Name: dsmr_consumption_consumptionsettings; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_consumption_consumptionsettings (
    id integer NOT NULL,
    electricity_grouping_type integer NOT NULL,
    gas_grouping_type integer NOT NULL
);


ALTER TABLE public.dsmr_consumption_consumptionsettings OWNER TO dsmrreader;

--
-- Name: dsmr_consumption_consumptionsettings_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_consumption_consumptionsettings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_consumption_consumptionsettings_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_consumption_consumptionsettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_consumption_consumptionsettings_id_seq OWNED BY public.dsmr_consumption_consumptionsettings.id;


--
-- Name: dsmr_consumption_electricityconsumption; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_consumption_electricityconsumption (
    id integer NOT NULL,
    read_at timestamp with time zone NOT NULL,
    delivered_1 numeric(9,3) NOT NULL,
    returned_1 numeric(9,3) NOT NULL,
    delivered_2 numeric(9,3) NOT NULL,
    returned_2 numeric(9,3) NOT NULL,
    currently_delivered numeric(9,3) NOT NULL,
    currently_returned numeric(9,3) NOT NULL,
    phase_currently_delivered_l1 numeric(9,3),
    phase_currently_delivered_l2 numeric(9,3),
    phase_currently_delivered_l3 numeric(9,3),
    phase_currently_returned_l1 numeric(9,3),
    phase_currently_returned_l2 numeric(9,3),
    phase_currently_returned_l3 numeric(9,3),
    phase_voltage_l1 numeric(4,1),
    phase_voltage_l2 numeric(4,1),
    phase_voltage_l3 numeric(4,1),
    phase_power_current_l1 integer,
    phase_power_current_l2 integer,
    phase_power_current_l3 integer
);


ALTER TABLE public.dsmr_consumption_electricityconsumption OWNER TO dsmrreader;

--
-- Name: dsmr_consumption_electricityconsumption_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_consumption_electricityconsumption_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_consumption_electricityconsumption_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_consumption_electricityconsumption_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_consumption_electricityconsumption_id_seq OWNED BY public.dsmr_consumption_electricityconsumption.id;


--
-- Name: dsmr_consumption_energysupplierprice; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_consumption_energysupplierprice (
    id integer NOT NULL,
    start date NOT NULL,
    "end" date NOT NULL,
    electricity_delivered_1_price numeric(11,6) NOT NULL,
    electricity_delivered_2_price numeric(11,6) NOT NULL,
    gas_price numeric(11,6) NOT NULL,
    description character varying(255) NOT NULL,
    electricity_returned_1_price numeric(11,6) NOT NULL,
    electricity_returned_2_price numeric(11,6) NOT NULL,
    fixed_daily_cost numeric(11,6) NOT NULL
);


ALTER TABLE public.dsmr_consumption_energysupplierprice OWNER TO dsmrreader;

--
-- Name: dsmr_consumption_energysupplierprice_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_consumption_energysupplierprice_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_consumption_energysupplierprice_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_consumption_energysupplierprice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_consumption_energysupplierprice_id_seq OWNED BY public.dsmr_consumption_energysupplierprice.id;


--
-- Name: dsmr_consumption_gasconsumption; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_consumption_gasconsumption (
    id integer NOT NULL,
    read_at timestamp with time zone NOT NULL,
    delivered numeric(9,3) NOT NULL,
    currently_delivered numeric(9,3) NOT NULL
);


ALTER TABLE public.dsmr_consumption_gasconsumption OWNER TO dsmrreader;

--
-- Name: dsmr_consumption_gasconsumption_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_consumption_gasconsumption_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_consumption_gasconsumption_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_consumption_gasconsumption_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_consumption_gasconsumption_id_seq OWNED BY public.dsmr_consumption_gasconsumption.id;


--
-- Name: dsmr_consumption_quarterhourpeakelectricityconsumption; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_consumption_quarterhourpeakelectricityconsumption (
    id integer NOT NULL,
    read_at_start timestamp with time zone NOT NULL,
    read_at_end timestamp with time zone NOT NULL,
    average_delivered numeric(9,3) NOT NULL
);


ALTER TABLE public.dsmr_consumption_quarterhourpeakelectricityconsumption OWNER TO dsmrreader;

--
-- Name: dsmr_consumption_quarterhourpeakelectricityconsumption_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_consumption_quarterhourpeakelectricityconsumption_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_consumption_quarterhourpeakelectricityconsumption_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_consumption_quarterhourpeakelectricityconsumption_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_consumption_quarterhourpeakelectricityconsumption_id_seq OWNED BY public.dsmr_consumption_quarterhourpeakelectricityconsumption.id;


--
-- Name: dsmr_datalogger_dataloggersettings; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_datalogger_dataloggersettings (
    id integer NOT NULL,
    serial_port character varying(196),
    dsmr_version integer NOT NULL,
    process_sleep numeric(3,1) NOT NULL,
    input_method character varying(16) NOT NULL,
    network_socket_address character varying(196),
    network_socket_port integer NOT NULL,
    restart_required boolean NOT NULL,
    override_telegram_timestamp boolean NOT NULL,
    dsmr_extra_device_channel integer
);


ALTER TABLE public.dsmr_datalogger_dataloggersettings OWNER TO dsmrreader;

--
-- Name: dsmr_datalogger_dataloggersettings_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_datalogger_dataloggersettings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_datalogger_dataloggersettings_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_datalogger_dataloggersettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_datalogger_dataloggersettings_id_seq OWNED BY public.dsmr_datalogger_dataloggersettings.id;


--
-- Name: dsmr_datalogger_dsmrreading; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_datalogger_dsmrreading (
    id integer NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    electricity_delivered_1 numeric(9,3) NOT NULL,
    electricity_returned_1 numeric(9,3) NOT NULL,
    electricity_delivered_2 numeric(9,3) NOT NULL,
    electricity_returned_2 numeric(9,3) NOT NULL,
    electricity_currently_delivered numeric(9,3) NOT NULL,
    electricity_currently_returned numeric(9,3) NOT NULL,
    extra_device_timestamp timestamp with time zone,
    extra_device_delivered numeric(9,3),
    processed boolean NOT NULL,
    phase_currently_delivered_l1 numeric(9,3),
    phase_currently_delivered_l2 numeric(9,3),
    phase_currently_delivered_l3 numeric(9,3),
    phase_currently_returned_l1 numeric(9,3),
    phase_currently_returned_l2 numeric(9,3),
    phase_currently_returned_l3 numeric(9,3),
    phase_voltage_l1 numeric(4,1),
    phase_voltage_l2 numeric(4,1),
    phase_voltage_l3 numeric(4,1),
    phase_power_current_l1 integer,
    phase_power_current_l2 integer,
    phase_power_current_l3 integer
);


ALTER TABLE public.dsmr_datalogger_dsmrreading OWNER TO dsmrreader;

--
-- Name: dsmr_datalogger_dsmrreading_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_datalogger_dsmrreading_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_datalogger_dsmrreading_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_datalogger_dsmrreading_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_datalogger_dsmrreading_id_seq OWNED BY public.dsmr_datalogger_dsmrreading.id;


--
-- Name: dsmr_datalogger_meterstatistics; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_datalogger_meterstatistics (
    id integer NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    electricity_tariff integer,
    power_failure_count integer,
    long_power_failure_count integer,
    voltage_sag_count_l1 integer,
    voltage_sag_count_l2 integer,
    voltage_sag_count_l3 integer,
    voltage_swell_count_l1 integer,
    voltage_swell_count_l2 integer,
    voltage_swell_count_l3 integer,
    rejected_telegrams integer NOT NULL,
    dsmr_version character varying(2),
    latest_telegram text
);


ALTER TABLE public.dsmr_datalogger_meterstatistics OWNER TO dsmrreader;

--
-- Name: dsmr_datalogger_meterstatistics_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_datalogger_meterstatistics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_datalogger_meterstatistics_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_datalogger_meterstatistics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_datalogger_meterstatistics_id_seq OWNED BY public.dsmr_datalogger_meterstatistics.id;


--
-- Name: dsmr_datalogger_meterstatisticschange; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_datalogger_meterstatisticschange (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    field character varying(64) NOT NULL,
    old_value character varying(32) NOT NULL,
    new_value character varying(32) NOT NULL
);


ALTER TABLE public.dsmr_datalogger_meterstatisticschange OWNER TO dsmrreader;

--
-- Name: dsmr_datalogger_meterstatisticschange_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_datalogger_meterstatisticschange_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_datalogger_meterstatisticschange_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_datalogger_meterstatisticschange_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_datalogger_meterstatisticschange_id_seq OWNED BY public.dsmr_datalogger_meterstatisticschange.id;


--
-- Name: dsmr_datalogger_retentionsettings; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_datalogger_retentionsettings (
    id integer NOT NULL,
    data_retention_in_hours integer
);


ALTER TABLE public.dsmr_datalogger_retentionsettings OWNER TO dsmrreader;

--
-- Name: dsmr_datalogger_retentionsettings_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_datalogger_retentionsettings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_datalogger_retentionsettings_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_datalogger_retentionsettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_datalogger_retentionsettings_id_seq OWNED BY public.dsmr_datalogger_retentionsettings.id;


--
-- Name: dsmr_frontend_frontendsettings; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_frontend_frontendsettings (
    id integer NOT NULL,
    electricity_delivered_alternate_color character varying(18) NOT NULL,
    electricity_delivered_color character varying(18) NOT NULL,
    electricity_returned_alternate_color character varying(18) NOT NULL,
    electricity_returned_color character varying(18) NOT NULL,
    gas_delivered_color character varying(18) NOT NULL,
    temperature_color character varying(18) NOT NULL,
    merge_electricity_tariffs boolean NOT NULL,
    phase_delivered_l1_color character varying(18) NOT NULL,
    phase_delivered_l2_color character varying(18) NOT NULL,
    phase_delivered_l3_color character varying(18) NOT NULL,
    phase_returned_l1_color character varying(18) NOT NULL,
    phase_returned_l2_color character varying(18) NOT NULL,
    phase_returned_l3_color character varying(18) NOT NULL,
    gas_graph_style character varying(4) NOT NULL,
    electricity_graph_style character varying(4) NOT NULL,
    stack_electricity_graphs boolean NOT NULL,
    tariff_1_delivered_name character varying(30) NOT NULL,
    tariff_1_returned_name character varying(30) NOT NULL,
    tariff_2_delivered_name character varying(30) NOT NULL,
    tariff_2_returned_name character varying(30) NOT NULL,
    live_graphs_hours_range integer NOT NULL,
    live_graphs_initial_zoom integer NOT NULL,
    always_require_login boolean NOT NULL,
    frontend_theme integer NOT NULL,
    gui_refresh_interval integer NOT NULL
);


ALTER TABLE public.dsmr_frontend_frontendsettings OWNER TO dsmrreader;

--
-- Name: dsmr_frontend_frontendsettings_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_frontend_frontendsettings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_frontend_frontendsettings_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_frontend_frontendsettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_frontend_frontendsettings_id_seq OWNED BY public.dsmr_frontend_frontendsettings.id;


--
-- Name: dsmr_frontend_notification; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_frontend_notification (
    id integer NOT NULL,
    message text NOT NULL,
    redirect_to character varying(64),
    read boolean NOT NULL
);


ALTER TABLE public.dsmr_frontend_notification OWNER TO dsmrreader;

--
-- Name: dsmr_frontend_notification_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_frontend_notification_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_frontend_notification_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_frontend_notification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_frontend_notification_id_seq OWNED BY public.dsmr_frontend_notification.id;


--
-- Name: dsmr_frontend_sortedgraph; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_frontend_sortedgraph (
    id integer NOT NULL,
    name character varying(64) NOT NULL,
    graph_type character varying(32) NOT NULL,
    sorting_order integer NOT NULL,
    CONSTRAINT dsmr_frontend_sortedgraph_sorting_order_check CHECK ((sorting_order >= 0))
);


ALTER TABLE public.dsmr_frontend_sortedgraph OWNER TO dsmrreader;

--
-- Name: dsmr_frontend_sortedgraph_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_frontend_sortedgraph_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_frontend_sortedgraph_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_frontend_sortedgraph_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_frontend_sortedgraph_id_seq OWNED BY public.dsmr_frontend_sortedgraph.id;


--
-- Name: dsmr_influxdb_influxdbintegrationsettings; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_influxdb_influxdbintegrationsettings (
    id integer NOT NULL,
    enabled boolean NOT NULL,
    hostname character varying(128) NOT NULL,
    port integer NOT NULL,
    bucket character varying(128) NOT NULL,
    secure character varying(24) NOT NULL,
    formatting text NOT NULL,
    api_token character varying(128) NOT NULL,
    organization character varying(128) NOT NULL
);


ALTER TABLE public.dsmr_influxdb_influxdbintegrationsettings OWNER TO dsmrreader;

--
-- Name: dsmr_influxdb_influxdbintegrationsettings_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_influxdb_influxdbintegrationsettings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_influxdb_influxdbintegrationsettings_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_influxdb_influxdbintegrationsettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_influxdb_influxdbintegrationsettings_id_seq OWNED BY public.dsmr_influxdb_influxdbintegrationsettings.id;


--
-- Name: dsmr_influxdb_influxdbmeasurement; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_influxdb_influxdbmeasurement (
    id integer NOT NULL,
    "time" timestamp with time zone NOT NULL,
    measurement_name character varying(255) NOT NULL,
    fields text NOT NULL
);


ALTER TABLE public.dsmr_influxdb_influxdbmeasurement OWNER TO dsmrreader;

--
-- Name: dsmr_influxdb_influxdbmeasurement_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_influxdb_influxdbmeasurement_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_influxdb_influxdbmeasurement_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_influxdb_influxdbmeasurement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_influxdb_influxdbmeasurement_id_seq OWNED BY public.dsmr_influxdb_influxdbmeasurement.id;


--
-- Name: dsmr_mindergas_mindergassettings; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_mindergas_mindergassettings (
    id integer NOT NULL,
    export boolean NOT NULL,
    auth_token character varying(64)
);


ALTER TABLE public.dsmr_mindergas_mindergassettings OWNER TO dsmrreader;

--
-- Name: dsmr_mindergas_mindergassettings_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_mindergas_mindergassettings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_mindergas_mindergassettings_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_mindergas_mindergassettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_mindergas_mindergassettings_id_seq OWNED BY public.dsmr_mindergas_mindergassettings.id;


--
-- Name: dsmr_mqtt_jsoncurrentperiodtotalsmqttsettings; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_mqtt_jsoncurrentperiodtotalsmqttsettings (
    id integer NOT NULL,
    enabled boolean NOT NULL,
    topic character varying(256) NOT NULL,
    formatting text NOT NULL
);


ALTER TABLE public.dsmr_mqtt_jsoncurrentperiodtotalsmqttsettings OWNER TO dsmrreader;

--
-- Name: dsmr_mqtt_jsoncurrentperiodtotalsmqttsettings_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_mqtt_jsoncurrentperiodtotalsmqttsettings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_mqtt_jsoncurrentperiodtotalsmqttsettings_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_mqtt_jsoncurrentperiodtotalsmqttsettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_mqtt_jsoncurrentperiodtotalsmqttsettings_id_seq OWNED BY public.dsmr_mqtt_jsoncurrentperiodtotalsmqttsettings.id;


--
-- Name: dsmr_mqtt_jsondaytotalsmqttsettings; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_mqtt_jsondaytotalsmqttsettings (
    id integer NOT NULL,
    enabled boolean NOT NULL,
    topic character varying(256) NOT NULL,
    formatting text NOT NULL
);


ALTER TABLE public.dsmr_mqtt_jsondaytotalsmqttsettings OWNER TO dsmrreader;

--
-- Name: dsmr_mqtt_jsondaytotalsmqttsettings_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_mqtt_jsondaytotalsmqttsettings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_mqtt_jsondaytotalsmqttsettings_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_mqtt_jsondaytotalsmqttsettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_mqtt_jsondaytotalsmqttsettings_id_seq OWNED BY public.dsmr_mqtt_jsondaytotalsmqttsettings.id;


--
-- Name: dsmr_mqtt_jsongasconsumptionmqttsettings; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_mqtt_jsongasconsumptionmqttsettings (
    id integer NOT NULL,
    enabled boolean NOT NULL,
    topic character varying(256) NOT NULL,
    formatting text NOT NULL
);


ALTER TABLE public.dsmr_mqtt_jsongasconsumptionmqttsettings OWNER TO dsmrreader;

--
-- Name: dsmr_mqtt_jsongasconsumptionmqttsettings_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_mqtt_jsongasconsumptionmqttsettings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_mqtt_jsongasconsumptionmqttsettings_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_mqtt_jsongasconsumptionmqttsettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_mqtt_jsongasconsumptionmqttsettings_id_seq OWNED BY public.dsmr_mqtt_jsongasconsumptionmqttsettings.id;


--
-- Name: dsmr_mqtt_jsonquarterhourpeakelectricityconsumptionmqttsettings; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_mqtt_jsonquarterhourpeakelectricityconsumptionmqttsettings (
    id integer NOT NULL,
    enabled boolean NOT NULL,
    topic character varying(256) NOT NULL,
    formatting text NOT NULL
);


ALTER TABLE public.dsmr_mqtt_jsonquarterhourpeakelectricityconsumptionmqttsettings OWNER TO dsmrreader;

--
-- Name: dsmr_mqtt_jsonquarterhourpeakelectricityconsumptionmqtts_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_mqtt_jsonquarterhourpeakelectricityconsumptionmqtts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_mqtt_jsonquarterhourpeakelectricityconsumptionmqtts_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_mqtt_jsonquarterhourpeakelectricityconsumptionmqtts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_mqtt_jsonquarterhourpeakelectricityconsumptionmqtts_id_seq OWNED BY public.dsmr_mqtt_jsonquarterhourpeakelectricityconsumptionmqttsettings.id;


--
-- Name: dsmr_mqtt_jsontelegrammqttsettings; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_mqtt_jsontelegrammqttsettings (
    id integer NOT NULL,
    enabled boolean NOT NULL,
    topic character varying(256) NOT NULL,
    formatting text NOT NULL,
    use_local_timezone boolean NOT NULL
);


ALTER TABLE public.dsmr_mqtt_jsontelegrammqttsettings OWNER TO dsmrreader;

--
-- Name: dsmr_mqtt_jsontelegrammqttsettings_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_mqtt_jsontelegrammqttsettings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_mqtt_jsontelegrammqttsettings_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_mqtt_jsontelegrammqttsettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_mqtt_jsontelegrammqttsettings_id_seq OWNED BY public.dsmr_mqtt_jsontelegrammqttsettings.id;


--
-- Name: dsmr_mqtt_message; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_mqtt_message (
    id integer NOT NULL,
    topic character varying(255) NOT NULL,
    payload text
);


ALTER TABLE public.dsmr_mqtt_message OWNER TO dsmrreader;

--
-- Name: dsmr_mqtt_message_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_mqtt_message_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_mqtt_message_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_mqtt_message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_mqtt_message_id_seq OWNED BY public.dsmr_mqtt_message.id;


--
-- Name: dsmr_mqtt_mqttbrokersettings; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_mqtt_mqttbrokersettings (
    id integer NOT NULL,
    hostname character varying(256) NOT NULL,
    port integer,
    username character varying(256),
    password character varying(256),
    client_id character varying(256) NOT NULL,
    restart_required boolean NOT NULL,
    secure integer NOT NULL,
    enabled boolean NOT NULL
);


ALTER TABLE public.dsmr_mqtt_mqttbrokersettings OWNER TO dsmrreader;

--
-- Name: dsmr_mqtt_mqttbrokersettings_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_mqtt_mqttbrokersettings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_mqtt_mqttbrokersettings_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_mqtt_mqttbrokersettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_mqtt_mqttbrokersettings_id_seq OWNED BY public.dsmr_mqtt_mqttbrokersettings.id;


--
-- Name: dsmr_mqtt_rawtelegrammqttsettings; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_mqtt_rawtelegrammqttsettings (
    id integer NOT NULL,
    enabled boolean NOT NULL,
    topic character varying(256) NOT NULL
);


ALTER TABLE public.dsmr_mqtt_rawtelegrammqttsettings OWNER TO dsmrreader;

--
-- Name: dsmr_mqtt_rawtelegrammqttsettings_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_mqtt_rawtelegrammqttsettings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_mqtt_rawtelegrammqttsettings_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_mqtt_rawtelegrammqttsettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_mqtt_rawtelegrammqttsettings_id_seq OWNED BY public.dsmr_mqtt_rawtelegrammqttsettings.id;


--
-- Name: dsmr_mqtt_splittopiccurrentperiodtotalsmqttsettings; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_mqtt_splittopiccurrentperiodtotalsmqttsettings (
    id integer NOT NULL,
    enabled boolean NOT NULL,
    formatting text NOT NULL
);


ALTER TABLE public.dsmr_mqtt_splittopiccurrentperiodtotalsmqttsettings OWNER TO dsmrreader;

--
-- Name: dsmr_mqtt_splittopiccurrentperiodtotalsmqttsettings_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_mqtt_splittopiccurrentperiodtotalsmqttsettings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_mqtt_splittopiccurrentperiodtotalsmqttsettings_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_mqtt_splittopiccurrentperiodtotalsmqttsettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_mqtt_splittopiccurrentperiodtotalsmqttsettings_id_seq OWNED BY public.dsmr_mqtt_splittopiccurrentperiodtotalsmqttsettings.id;


--
-- Name: dsmr_mqtt_splittopicdaytotalsmqttsettings; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_mqtt_splittopicdaytotalsmqttsettings (
    id integer NOT NULL,
    enabled boolean NOT NULL,
    formatting text NOT NULL
);


ALTER TABLE public.dsmr_mqtt_splittopicdaytotalsmqttsettings OWNER TO dsmrreader;

--
-- Name: dsmr_mqtt_splittopicdaytotalsmqttsettings_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_mqtt_splittopicdaytotalsmqttsettings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_mqtt_splittopicdaytotalsmqttsettings_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_mqtt_splittopicdaytotalsmqttsettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_mqtt_splittopicdaytotalsmqttsettings_id_seq OWNED BY public.dsmr_mqtt_splittopicdaytotalsmqttsettings.id;


--
-- Name: dsmr_mqtt_splittopicgasconsumptionmqttsettings; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_mqtt_splittopicgasconsumptionmqttsettings (
    id integer NOT NULL,
    enabled boolean NOT NULL,
    formatting text NOT NULL
);


ALTER TABLE public.dsmr_mqtt_splittopicgasconsumptionmqttsettings OWNER TO dsmrreader;

--
-- Name: dsmr_mqtt_splittopicgasconsumptionmqttsettings_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_mqtt_splittopicgasconsumptionmqttsettings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_mqtt_splittopicgasconsumptionmqttsettings_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_mqtt_splittopicgasconsumptionmqttsettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_mqtt_splittopicgasconsumptionmqttsettings_id_seq OWNED BY public.dsmr_mqtt_splittopicgasconsumptionmqttsettings.id;


--
-- Name: dsmr_mqtt_splittopicmeterstatisticsmqttsettings; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_mqtt_splittopicmeterstatisticsmqttsettings (
    id integer NOT NULL,
    enabled boolean NOT NULL,
    formatting text NOT NULL
);


ALTER TABLE public.dsmr_mqtt_splittopicmeterstatisticsmqttsettings OWNER TO dsmrreader;

--
-- Name: dsmr_mqtt_splittopicmeterstatisticsmqttsettings_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_mqtt_splittopicmeterstatisticsmqttsettings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_mqtt_splittopicmeterstatisticsmqttsettings_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_mqtt_splittopicmeterstatisticsmqttsettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_mqtt_splittopicmeterstatisticsmqttsettings_id_seq OWNED BY public.dsmr_mqtt_splittopicmeterstatisticsmqttsettings.id;


--
-- Name: dsmr_mqtt_splittopicquarterhourpeakelectricityconsumptionmqf25c; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_mqtt_splittopicquarterhourpeakelectricityconsumptionmqf25c (
    id integer NOT NULL,
    enabled boolean NOT NULL,
    formatting text NOT NULL
);


ALTER TABLE public.dsmr_mqtt_splittopicquarterhourpeakelectricityconsumptionmqf25c OWNER TO dsmrreader;

--
-- Name: dsmr_mqtt_splittopicquarterhourpeakelectricityconsumptio_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_mqtt_splittopicquarterhourpeakelectricityconsumptio_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_mqtt_splittopicquarterhourpeakelectricityconsumptio_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_mqtt_splittopicquarterhourpeakelectricityconsumptio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_mqtt_splittopicquarterhourpeakelectricityconsumptio_id_seq OWNED BY public.dsmr_mqtt_splittopicquarterhourpeakelectricityconsumptionmqf25c.id;


--
-- Name: dsmr_mqtt_splittopictelegrammqttsettings; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_mqtt_splittopictelegrammqttsettings (
    id integer NOT NULL,
    enabled boolean NOT NULL,
    formatting text NOT NULL,
    use_local_timezone boolean NOT NULL
);


ALTER TABLE public.dsmr_mqtt_splittopictelegrammqttsettings OWNER TO dsmrreader;

--
-- Name: dsmr_mqtt_splittopictelegrammqttsettings_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_mqtt_splittopictelegrammqttsettings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_mqtt_splittopictelegrammqttsettings_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_mqtt_splittopictelegrammqttsettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_mqtt_splittopictelegrammqttsettings_id_seq OWNED BY public.dsmr_mqtt_splittopictelegrammqttsettings.id;


--
-- Name: dsmr_notification_notificationsetting; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_notification_notificationsetting (
    id integer NOT NULL,
    notification_service character varying(20),
    next_notification timestamp with time zone,
    prowl_api_key character varying(64),
    pushover_api_key character varying(64),
    pushover_user_key character varying(64),
    telegram_api_key character varying(64),
    telegram_chat_id character varying(64)
);


ALTER TABLE public.dsmr_notification_notificationsetting OWNER TO dsmrreader;

--
-- Name: dsmr_notification_notificationsetting_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_notification_notificationsetting_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_notification_notificationsetting_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_notification_notificationsetting_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_notification_notificationsetting_id_seq OWNED BY public.dsmr_notification_notificationsetting.id;


--
-- Name: dsmr_notification_statusnotificationsetting; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_notification_statusnotificationsetting (
    id integer NOT NULL,
    next_check timestamp with time zone
);


ALTER TABLE public.dsmr_notification_statusnotificationsetting OWNER TO dsmrreader;

--
-- Name: dsmr_notification_statusnotificationsetting_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_notification_statusnotificationsetting_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_notification_statusnotificationsetting_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_notification_statusnotificationsetting_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_notification_statusnotificationsetting_id_seq OWNED BY public.dsmr_notification_statusnotificationsetting.id;


--
-- Name: dsmr_pvoutput_pvoutputaddstatussettings; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_pvoutput_pvoutputaddstatussettings (
    id integer NOT NULL,
    export boolean NOT NULL,
    upload_interval integer NOT NULL,
    upload_delay integer NOT NULL,
    processing_delay integer
);


ALTER TABLE public.dsmr_pvoutput_pvoutputaddstatussettings OWNER TO dsmrreader;

--
-- Name: dsmr_pvoutput_pvoutputaddstatussettings_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_pvoutput_pvoutputaddstatussettings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_pvoutput_pvoutputaddstatussettings_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_pvoutput_pvoutputaddstatussettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_pvoutput_pvoutputaddstatussettings_id_seq OWNED BY public.dsmr_pvoutput_pvoutputaddstatussettings.id;


--
-- Name: dsmr_pvoutput_pvoutputapisettings; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_pvoutput_pvoutputapisettings (
    id integer NOT NULL,
    auth_token character varying(256),
    system_identifier character varying(32)
);


ALTER TABLE public.dsmr_pvoutput_pvoutputapisettings OWNER TO dsmrreader;

--
-- Name: dsmr_pvoutput_pvoutputapisettings_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_pvoutput_pvoutputapisettings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_pvoutput_pvoutputapisettings_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_pvoutput_pvoutputapisettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_pvoutput_pvoutputapisettings_id_seq OWNED BY public.dsmr_pvoutput_pvoutputapisettings.id;


--
-- Name: dsmr_stats_daystatistics; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_stats_daystatistics (
    id integer NOT NULL,
    day date NOT NULL,
    total_cost numeric(8,2) NOT NULL,
    electricity1 numeric(9,3) NOT NULL,
    electricity2 numeric(9,3) NOT NULL,
    electricity1_returned numeric(9,3) NOT NULL,
    electricity2_returned numeric(9,3) NOT NULL,
    electricity1_cost numeric(8,2) NOT NULL,
    electricity2_cost numeric(8,2) NOT NULL,
    gas numeric(9,3),
    gas_cost numeric(8,2),
    average_temperature numeric(4,1),
    highest_temperature numeric(4,1),
    lowest_temperature numeric(4,1),
    fixed_cost numeric(8,2) NOT NULL,
    electricity1_reading numeric(9,3),
    electricity1_returned_reading numeric(9,3),
    electricity2_reading numeric(9,3),
    electricity2_returned_reading numeric(9,3),
    gas_reading numeric(9,3),
    electricity_reading_timestamp timestamp with time zone,
    gas_reading_timestamp timestamp with time zone
);


ALTER TABLE public.dsmr_stats_daystatistics OWNER TO dsmrreader;

--
-- Name: dsmr_stats_daystatistics_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_stats_daystatistics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_stats_daystatistics_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_stats_daystatistics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_stats_daystatistics_id_seq OWNED BY public.dsmr_stats_daystatistics.id;


--
-- Name: dsmr_stats_electricitystatistics; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_stats_electricitystatistics (
    id integer NOT NULL,
    highest_usage_l1_timestamp timestamp with time zone,
    highest_usage_l2_timestamp timestamp with time zone,
    highest_usage_l3_timestamp timestamp with time zone,
    highest_return_l1_timestamp timestamp with time zone,
    highest_return_l2_timestamp timestamp with time zone,
    highest_return_l3_timestamp timestamp with time zone,
    highest_usage_l1_value numeric(9,3),
    highest_usage_l2_value numeric(9,3),
    highest_usage_l3_value numeric(9,3),
    highest_return_l1_value numeric(9,3),
    highest_return_l2_value numeric(9,3),
    highest_return_l3_value numeric(9,3),
    lowest_usage_l1_timestamp timestamp with time zone,
    lowest_usage_l1_value numeric(9,3),
    lowest_usage_l2_timestamp timestamp with time zone,
    lowest_usage_l2_value numeric(9,3),
    lowest_usage_l3_timestamp timestamp with time zone,
    lowest_usage_l3_value numeric(9,3)
);


ALTER TABLE public.dsmr_stats_electricitystatistics OWNER TO dsmrreader;

--
-- Name: dsmr_stats_electricitystatistics_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_stats_electricitystatistics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_stats_electricitystatistics_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_stats_electricitystatistics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_stats_electricitystatistics_id_seq OWNED BY public.dsmr_stats_electricitystatistics.id;


--
-- Name: dsmr_stats_hourstatistics; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_stats_hourstatistics (
    id integer NOT NULL,
    hour_start timestamp with time zone NOT NULL,
    electricity1 numeric(9,3) NOT NULL,
    electricity2 numeric(9,3) NOT NULL,
    electricity1_returned numeric(9,3) NOT NULL,
    electricity2_returned numeric(9,3) NOT NULL,
    gas numeric(9,3) NOT NULL
);


ALTER TABLE public.dsmr_stats_hourstatistics OWNER TO dsmrreader;

--
-- Name: dsmr_stats_hourstatistics_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_stats_hourstatistics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_stats_hourstatistics_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_stats_hourstatistics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_stats_hourstatistics_id_seq OWNED BY public.dsmr_stats_hourstatistics.id;


--
-- Name: dsmr_stats_note; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_stats_note (
    id integer NOT NULL,
    day date NOT NULL,
    description character varying(256) NOT NULL
);


ALTER TABLE public.dsmr_stats_note OWNER TO dsmrreader;

--
-- Name: dsmr_stats_note_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_stats_note_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_stats_note_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_stats_note_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_stats_note_id_seq OWNED BY public.dsmr_stats_note.id;


--
-- Name: dsmr_weather_temperaturereading; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_weather_temperaturereading (
    id integer NOT NULL,
    read_at timestamp with time zone NOT NULL,
    degrees_celcius numeric(4,1) NOT NULL
);


ALTER TABLE public.dsmr_weather_temperaturereading OWNER TO dsmrreader;

--
-- Name: dsmr_weather_temperaturereading_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_weather_temperaturereading_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_weather_temperaturereading_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_weather_temperaturereading_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_weather_temperaturereading_id_seq OWNED BY public.dsmr_weather_temperaturereading.id;


--
-- Name: dsmr_weather_weathersettings; Type: TABLE; Schema: public; Owner: dsmrreader
--

CREATE TABLE public.dsmr_weather_weathersettings (
    id integer NOT NULL,
    track boolean NOT NULL,
    buienradar_station integer NOT NULL
);


ALTER TABLE public.dsmr_weather_weathersettings OWNER TO dsmrreader;

--
-- Name: dsmr_weather_weathersettings_id_seq; Type: SEQUENCE; Schema: public; Owner: dsmrreader
--

CREATE SEQUENCE public.dsmr_weather_weathersettings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dsmr_weather_weathersettings_id_seq OWNER TO dsmrreader;

--
-- Name: dsmr_weather_weathersettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dsmrreader
--

ALTER SEQUENCE public.dsmr_weather_weathersettings_id_seq OWNED BY public.dsmr_weather_weathersettings.id;


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: auth_user id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.auth_user ALTER COLUMN id SET DEFAULT nextval('public.auth_user_id_seq'::regclass);


--
-- Name: auth_user_groups id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.auth_user_groups ALTER COLUMN id SET DEFAULT nextval('public.auth_user_groups_id_seq'::regclass);


--
-- Name: auth_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_user_user_permissions_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: dsmr_api_apisettings id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_api_apisettings ALTER COLUMN id SET DEFAULT nextval('public.dsmr_api_apisettings_id_seq'::regclass);


--
-- Name: dsmr_backend_backendsettings id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_backend_backendsettings ALTER COLUMN id SET DEFAULT nextval('public.dsmr_backend_backendsettings_id_seq'::regclass);


--
-- Name: dsmr_backend_emailsettings id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_backend_emailsettings ALTER COLUMN id SET DEFAULT nextval('public.dsmr_backend_emailsettings_id_seq'::regclass);


--
-- Name: dsmr_backend_scheduledprocess id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_backend_scheduledprocess ALTER COLUMN id SET DEFAULT nextval('public.dsmr_backend_scheduledprocess_id_seq'::regclass);


--
-- Name: dsmr_backup_backupsettings id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_backup_backupsettings ALTER COLUMN id SET DEFAULT nextval('public.dsmr_backup_backupsettings_id_seq'::regclass);


--
-- Name: dsmr_backup_dropboxsettings id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_backup_dropboxsettings ALTER COLUMN id SET DEFAULT nextval('public.dsmr_backup_dropboxsettings_id_seq'::regclass);


--
-- Name: dsmr_backup_emailbackupsettings id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_backup_emailbackupsettings ALTER COLUMN id SET DEFAULT nextval('public.dsmr_backup_emailbackupsettings_id_seq'::regclass);


--
-- Name: dsmr_consumption_consumptionsettings id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_consumption_consumptionsettings ALTER COLUMN id SET DEFAULT nextval('public.dsmr_consumption_consumptionsettings_id_seq'::regclass);


--
-- Name: dsmr_consumption_electricityconsumption id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_consumption_electricityconsumption ALTER COLUMN id SET DEFAULT nextval('public.dsmr_consumption_electricityconsumption_id_seq'::regclass);


--
-- Name: dsmr_consumption_energysupplierprice id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_consumption_energysupplierprice ALTER COLUMN id SET DEFAULT nextval('public.dsmr_consumption_energysupplierprice_id_seq'::regclass);


--
-- Name: dsmr_consumption_gasconsumption id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_consumption_gasconsumption ALTER COLUMN id SET DEFAULT nextval('public.dsmr_consumption_gasconsumption_id_seq'::regclass);


--
-- Name: dsmr_consumption_quarterhourpeakelectricityconsumption id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_consumption_quarterhourpeakelectricityconsumption ALTER COLUMN id SET DEFAULT nextval('public.dsmr_consumption_quarterhourpeakelectricityconsumption_id_seq'::regclass);


--
-- Name: dsmr_datalogger_dataloggersettings id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_datalogger_dataloggersettings ALTER COLUMN id SET DEFAULT nextval('public.dsmr_datalogger_dataloggersettings_id_seq'::regclass);


--
-- Name: dsmr_datalogger_dsmrreading id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_datalogger_dsmrreading ALTER COLUMN id SET DEFAULT nextval('public.dsmr_datalogger_dsmrreading_id_seq'::regclass);


--
-- Name: dsmr_datalogger_meterstatistics id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_datalogger_meterstatistics ALTER COLUMN id SET DEFAULT nextval('public.dsmr_datalogger_meterstatistics_id_seq'::regclass);


--
-- Name: dsmr_datalogger_meterstatisticschange id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_datalogger_meterstatisticschange ALTER COLUMN id SET DEFAULT nextval('public.dsmr_datalogger_meterstatisticschange_id_seq'::regclass);


--
-- Name: dsmr_datalogger_retentionsettings id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_datalogger_retentionsettings ALTER COLUMN id SET DEFAULT nextval('public.dsmr_datalogger_retentionsettings_id_seq'::regclass);


--
-- Name: dsmr_frontend_frontendsettings id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_frontend_frontendsettings ALTER COLUMN id SET DEFAULT nextval('public.dsmr_frontend_frontendsettings_id_seq'::regclass);


--
-- Name: dsmr_frontend_notification id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_frontend_notification ALTER COLUMN id SET DEFAULT nextval('public.dsmr_frontend_notification_id_seq'::regclass);


--
-- Name: dsmr_frontend_sortedgraph id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_frontend_sortedgraph ALTER COLUMN id SET DEFAULT nextval('public.dsmr_frontend_sortedgraph_id_seq'::regclass);


--
-- Name: dsmr_influxdb_influxdbintegrationsettings id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_influxdb_influxdbintegrationsettings ALTER COLUMN id SET DEFAULT nextval('public.dsmr_influxdb_influxdbintegrationsettings_id_seq'::regclass);


--
-- Name: dsmr_influxdb_influxdbmeasurement id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_influxdb_influxdbmeasurement ALTER COLUMN id SET DEFAULT nextval('public.dsmr_influxdb_influxdbmeasurement_id_seq'::regclass);


--
-- Name: dsmr_mindergas_mindergassettings id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_mindergas_mindergassettings ALTER COLUMN id SET DEFAULT nextval('public.dsmr_mindergas_mindergassettings_id_seq'::regclass);


--
-- Name: dsmr_mqtt_jsoncurrentperiodtotalsmqttsettings id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_mqtt_jsoncurrentperiodtotalsmqttsettings ALTER COLUMN id SET DEFAULT nextval('public.dsmr_mqtt_jsoncurrentperiodtotalsmqttsettings_id_seq'::regclass);


--
-- Name: dsmr_mqtt_jsondaytotalsmqttsettings id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_mqtt_jsondaytotalsmqttsettings ALTER COLUMN id SET DEFAULT nextval('public.dsmr_mqtt_jsondaytotalsmqttsettings_id_seq'::regclass);


--
-- Name: dsmr_mqtt_jsongasconsumptionmqttsettings id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_mqtt_jsongasconsumptionmqttsettings ALTER COLUMN id SET DEFAULT nextval('public.dsmr_mqtt_jsongasconsumptionmqttsettings_id_seq'::regclass);


--
-- Name: dsmr_mqtt_jsonquarterhourpeakelectricityconsumptionmqttsettings id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_mqtt_jsonquarterhourpeakelectricityconsumptionmqttsettings ALTER COLUMN id SET DEFAULT nextval('public.dsmr_mqtt_jsonquarterhourpeakelectricityconsumptionmqtts_id_seq'::regclass);


--
-- Name: dsmr_mqtt_jsontelegrammqttsettings id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_mqtt_jsontelegrammqttsettings ALTER COLUMN id SET DEFAULT nextval('public.dsmr_mqtt_jsontelegrammqttsettings_id_seq'::regclass);


--
-- Name: dsmr_mqtt_message id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_mqtt_message ALTER COLUMN id SET DEFAULT nextval('public.dsmr_mqtt_message_id_seq'::regclass);


--
-- Name: dsmr_mqtt_mqttbrokersettings id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_mqtt_mqttbrokersettings ALTER COLUMN id SET DEFAULT nextval('public.dsmr_mqtt_mqttbrokersettings_id_seq'::regclass);


--
-- Name: dsmr_mqtt_rawtelegrammqttsettings id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_mqtt_rawtelegrammqttsettings ALTER COLUMN id SET DEFAULT nextval('public.dsmr_mqtt_rawtelegrammqttsettings_id_seq'::regclass);


--
-- Name: dsmr_mqtt_splittopiccurrentperiodtotalsmqttsettings id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_mqtt_splittopiccurrentperiodtotalsmqttsettings ALTER COLUMN id SET DEFAULT nextval('public.dsmr_mqtt_splittopiccurrentperiodtotalsmqttsettings_id_seq'::regclass);


--
-- Name: dsmr_mqtt_splittopicdaytotalsmqttsettings id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_mqtt_splittopicdaytotalsmqttsettings ALTER COLUMN id SET DEFAULT nextval('public.dsmr_mqtt_splittopicdaytotalsmqttsettings_id_seq'::regclass);


--
-- Name: dsmr_mqtt_splittopicgasconsumptionmqttsettings id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_mqtt_splittopicgasconsumptionmqttsettings ALTER COLUMN id SET DEFAULT nextval('public.dsmr_mqtt_splittopicgasconsumptionmqttsettings_id_seq'::regclass);


--
-- Name: dsmr_mqtt_splittopicmeterstatisticsmqttsettings id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_mqtt_splittopicmeterstatisticsmqttsettings ALTER COLUMN id SET DEFAULT nextval('public.dsmr_mqtt_splittopicmeterstatisticsmqttsettings_id_seq'::regclass);


--
-- Name: dsmr_mqtt_splittopicquarterhourpeakelectricityconsumptionmqf25c id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_mqtt_splittopicquarterhourpeakelectricityconsumptionmqf25c ALTER COLUMN id SET DEFAULT nextval('public.dsmr_mqtt_splittopicquarterhourpeakelectricityconsumptio_id_seq'::regclass);


--
-- Name: dsmr_mqtt_splittopictelegrammqttsettings id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_mqtt_splittopictelegrammqttsettings ALTER COLUMN id SET DEFAULT nextval('public.dsmr_mqtt_splittopictelegrammqttsettings_id_seq'::regclass);


--
-- Name: dsmr_notification_notificationsetting id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_notification_notificationsetting ALTER COLUMN id SET DEFAULT nextval('public.dsmr_notification_notificationsetting_id_seq'::regclass);


--
-- Name: dsmr_notification_statusnotificationsetting id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_notification_statusnotificationsetting ALTER COLUMN id SET DEFAULT nextval('public.dsmr_notification_statusnotificationsetting_id_seq'::regclass);


--
-- Name: dsmr_pvoutput_pvoutputaddstatussettings id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_pvoutput_pvoutputaddstatussettings ALTER COLUMN id SET DEFAULT nextval('public.dsmr_pvoutput_pvoutputaddstatussettings_id_seq'::regclass);


--
-- Name: dsmr_pvoutput_pvoutputapisettings id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_pvoutput_pvoutputapisettings ALTER COLUMN id SET DEFAULT nextval('public.dsmr_pvoutput_pvoutputapisettings_id_seq'::regclass);


--
-- Name: dsmr_stats_daystatistics id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_stats_daystatistics ALTER COLUMN id SET DEFAULT nextval('public.dsmr_stats_daystatistics_id_seq'::regclass);


--
-- Name: dsmr_stats_electricitystatistics id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_stats_electricitystatistics ALTER COLUMN id SET DEFAULT nextval('public.dsmr_stats_electricitystatistics_id_seq'::regclass);


--
-- Name: dsmr_stats_hourstatistics id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_stats_hourstatistics ALTER COLUMN id SET DEFAULT nextval('public.dsmr_stats_hourstatistics_id_seq'::regclass);


--
-- Name: dsmr_stats_note id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_stats_note ALTER COLUMN id SET DEFAULT nextval('public.dsmr_stats_note_id_seq'::regclass);


--
-- Name: dsmr_weather_temperaturereading id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_weather_temperaturereading ALTER COLUMN id SET DEFAULT nextval('public.dsmr_weather_temperaturereading_id_seq'::regclass);


--
-- Name: dsmr_weather_weathersettings id; Type: DEFAULT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_weather_weathersettings ALTER COLUMN id SET DEFAULT nextval('public.dsmr_weather_weathersettings_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can view log entry	1	view_logentry
5	Can add permission	2	add_permission
6	Can change permission	2	change_permission
7	Can delete permission	2	delete_permission
8	Can view permission	2	view_permission
9	Can add group	3	add_group
10	Can change group	3	change_group
11	Can delete group	3	delete_group
12	Can view group	3	view_group
13	Can add user	4	add_user
14	Can change user	4	change_user
15	Can delete user	4	delete_user
16	Can view user	4	view_user
17	Can add content type	5	add_contenttype
18	Can change content type	5	change_contenttype
19	Can delete content type	5	delete_contenttype
20	Can view content type	5	view_contenttype
21	Can add session	6	add_session
22	Can change session	6	change_session
23	Can delete session	6	delete_session
24	Can view session	6	view_session
25	Can delete Application notification	25	delete_notification
26	Can delete Outgoing MQTT message	35	delete_message
27	Can add Influxdb measurement	53	add_influxdbmeasurement
28	Can change Influxdb measurement	53	change_influxdbmeasurement
29	Can delete Influxdb measurement	53	delete_influxdbmeasurement
30	Can view Influxdb measurement	53	view_influxdbmeasurement
\.


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
1		\N	f	api-user			root@localhost	f	t	2023-02-24 12:59:20.807948+01
2	pbkdf2_sha256$260000$pzKHXlzRb8RpdVzRXTisMO$xgyxpSjyPgglPY3rolwEG72itxB/MjYIDqciH40fask=	\N	t	admin			admin@localhost	t	t	2023-02-24 12:59:25.632482+01
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	permission
3	auth	group
4	auth	user
5	contenttypes	contenttype
6	sessions	session
7	dsmr_api	apisettings
8	dsmr_backend	backendsettings
9	dsmr_backend	emailsettings
10	dsmr_backend	scheduledprocess
11	dsmr_backup	backupsettings
12	dsmr_backup	dropboxsettings
13	dsmr_backup	emailbackupsettings
14	dsmr_consumption	consumptionsettings
15	dsmr_consumption	electricityconsumption
16	dsmr_consumption	energysupplierprice
17	dsmr_consumption	gasconsumption
18	dsmr_consumption	quarterhourpeakelectricityconsumption
19	dsmr_datalogger	dataloggersettings
20	dsmr_datalogger	dsmrreading
21	dsmr_datalogger	meterstatistics
22	dsmr_datalogger	retentionsettings
23	dsmr_datalogger	meterstatisticschange
24	dsmr_frontend	frontendsettings
25	dsmr_frontend	notification
26	dsmr_frontend	sortedgraph
27	dsmr_mindergas	mindergassettings
28	dsmr_mqtt	mqttbrokersettings
29	dsmr_mqtt	rawtelegrammqttsettings
30	dsmr_mqtt	jsontelegrammqttsettings
31	dsmr_mqtt	splittopictelegrammqttsettings
32	dsmr_mqtt	jsondaytotalsmqttsettings
33	dsmr_mqtt	splittopicdaytotalsmqttsettings
34	dsmr_mqtt	splittopicmeterstatisticsmqttsettings
35	dsmr_mqtt	message
36	dsmr_mqtt	jsongasconsumptionmqttsettings
37	dsmr_mqtt	splittopicgasconsumptionmqttsettings
38	dsmr_mqtt	jsoncurrentperiodtotalsmqttsettings
39	dsmr_mqtt	splittopiccurrentperiodtotalsmqttsettings
40	dsmr_mqtt	jsonquarterhourpeakelectricityconsumptionmqttsettings
41	dsmr_mqtt	splittopicquarterhourpeakelectricityconsumptionmqttsettings
42	dsmr_notification	notificationsetting
43	dsmr_notification	statusnotificationsetting
44	dsmr_pvoutput	pvoutputaddstatussettings
45	dsmr_pvoutput	pvoutputapisettings
46	dsmr_stats	note
47	dsmr_stats	daystatistics
48	dsmr_stats	hourstatistics
49	dsmr_stats	electricitystatistics
50	dsmr_weather	temperaturereading
51	dsmr_weather	weathersettings
52	dsmr_influxdb	influxdbintegrationsettings
53	dsmr_influxdb	influxdbmeasurement
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2023-02-24 12:59:20.437114+01
2	auth	0001_initial	2023-02-24 12:59:20.611621+01
3	admin	0001_initial	2023-02-24 12:59:20.661564+01
4	admin	0002_logentry_remove_auto_add	2023-02-24 12:59:20.66831+01
5	admin	0003_logentry_add_action_flag_choices	2023-02-24 12:59:20.674146+01
6	contenttypes	0002_remove_content_type_name	2023-02-24 12:59:20.690446+01
7	auth	0002_alter_permission_name_max_length	2023-02-24 12:59:20.697194+01
8	auth	0003_alter_user_email_max_length	2023-02-24 12:59:20.704135+01
9	auth	0004_alter_user_username_opts	2023-02-24 12:59:20.709986+01
10	auth	0005_alter_user_last_login_null	2023-02-24 12:59:20.716324+01
11	auth	0006_require_contenttypes_0002	2023-02-24 12:59:20.719205+01
12	auth	0007_alter_validators_add_error_messages	2023-02-24 12:59:20.725239+01
13	auth	0008_alter_user_username_max_length	2023-02-24 12:59:20.742127+01
14	auth	0009_alter_user_last_name_max_length	2023-02-24 12:59:20.749766+01
15	auth	0010_alter_group_name_max_length	2023-02-24 12:59:20.760105+01
16	auth	0011_update_proxy_permissions	2023-02-24 12:59:20.765676+01
17	auth	0012_alter_user_first_name_max_length	2023-02-24 12:59:20.772553+01
18	dsmr_api	0001_api_settings	2023-02-24 12:59:20.785068+01
19	dsmr_api	0002_generate_random_auth_key	2023-02-24 12:59:20.796095+01
20	dsmr_api	0003_create_api_user	2023-02-24 12:59:20.810669+01
21	dsmr_backend	0001_backend_language	2023-02-24 12:59:20.823523+01
22	dsmr_backend	0002_email_settings	2023-02-24 12:59:20.844385+01
23	dsmr_backend	0003_scheduled_processes	2023-02-24 12:59:20.869534+01
24	dsmr_backend	0004_backend_schedule_process_active_flag	2023-02-24 12:59:20.886376+01
25	dsmr_backend	0005_schedule_auto_update_check	2023-02-24 12:59:20.900314+01
26	dsmr_backend	0006_backend_auto_update_check	2023-02-24 12:59:20.906777+01
27	dsmr_backend	0007_schedule_stats_generator	2023-02-24 12:59:20.915423+01
28	dsmr_backend	0008_scheduled_process_fields	2023-02-24 12:59:20.922133+01
29	dsmr_backend	0009_update_email_settings_mail_from	2023-02-24 12:59:20.927496+01
30	dsmr_backend	0010_process_sleep	2023-02-24 12:59:20.937202+01
31	dsmr_backend	0011_disable_capabilities	2023-02-24 12:59:20.947523+01
32	dsmr_backend	0012_fix_email_from	2023-02-24 12:59:20.959421+01
33	dsmr_backend	0013_allow_higher_backend_sleep	2023-02-24 12:59:20.963364+01
34	dsmr_backend	0014_verbose_field_translations	2023-02-24 12:59:20.9746+01
35	dsmr_backend	0015_backend_restart_required	2023-02-24 12:59:20.978962+01
36	dsmr_backup	0001_initial	2023-02-24 12:59:21.002879+01
37	dsmr_backup	0002_settings_documentation	2023-02-24 12:59:21.007752+01
38	dsmr_backup	0003_dropbox_sync_field	2023-02-24 12:59:21.011293+01
39	dsmr_backup	0004_custom_backup_path	2023-02-24 12:59:21.021952+01
40	dsmr_backup	0005_email_backup_settings	2023-02-24 12:59:21.043517+01
41	dsmr_backup	0006_scheduled_email_backup	2023-02-24 12:59:21.053952+01
42	dsmr_backup	0007_remove_backupsettings_compress	2023-02-24 12:59:21.058051+01
43	dsmr_backup	0008_verbose_field_translations	2023-02-24 12:59:21.061502+01
44	dsmr_backup	0009_compression_level	2023-02-24 12:59:21.0655+01
45	dsmr_backup	0010_schedule_backup	2023-02-24 12:59:21.079014+01
46	dsmr_backup	0011_remove_backupsettings_latest_backup	2023-02-24 12:59:21.083632+01
47	dsmr_backup	0012_increase_dropbox_token_length	2023-02-24 12:59:21.087976+01
48	dsmr_backup	0013_dropbox_setting_refactoring	2023-02-24 12:59:21.092713+01
49	dsmr_backup	0014_dropbox_oauth	2023-02-24 12:59:21.108669+01
50	dsmr_backup	0015_dropbox_app_key	2023-02-24 12:59:21.112397+01
51	dsmr_backup	0016_backup_interval_and_filename	2023-02-24 12:59:21.120997+01
52	dsmr_backup	0017_backup_interval_in_days	2023-02-24 12:59:21.126657+01
53	dsmr_consumption	0001_squashed_0004_recalculate_gas_consumption	2023-02-24 12:59:21.184677+01
54	dsmr_consumption	0002_verbose_text	2023-02-24 12:59:21.191879+01
55	dsmr_consumption	0003_electricity_consumption_indexes	2023-02-24 12:59:21.208117+01
56	dsmr_consumption	0004_merge_electricity_tariffs	2023-02-24 12:59:21.214094+01
57	dsmr_consumption	0005_phase_currently_delivered	2023-02-24 12:59:21.236117+01
58	dsmr_consumption	0006_dsmr_firmware_v5	2023-02-24 12:59:21.242725+01
59	dsmr_consumption	0007_settings_documentation	2023-02-24 12:59:21.246923+01
60	dsmr_consumption	0008_energysupplier_return_prices	2023-02-24 12:59:21.258106+01
61	dsmr_consumption	0009_consumption_settings_text	2023-02-24 12:59:21.261483+01
62	dsmr_consumption	0010_phases_currently_returned	2023-02-24 12:59:21.268596+01
63	dsmr_consumption	0011_track_phase_voltages	2023-02-24 12:59:21.275883+01
64	dsmr_consumption	0012_add_voltage_indexes	2023-02-24 12:59:21.296622+01
65	dsmr_consumption	0013_schedule_generate_consumption	2023-02-24 12:59:21.307495+01
66	dsmr_consumption	0014_gas_grouping	2023-02-24 12:59:21.314577+01
67	dsmr_consumption	0015_track_power_current	2023-02-24 12:59:21.32916+01
68	dsmr_consumption	0016_fixed_daily_cost	2023-02-24 12:59:21.334687+01
69	dsmr_consumption	0017_energy_supplier_price_refactoring	2023-02-24 12:59:21.390236+01
70	dsmr_consumption	0018_allow_inversed_fixed_costs	2023-02-24 12:59:21.396897+01
71	dsmr_consumption	0019_energy_supplier_price_decimals	2023-02-24 12:59:21.511475+01
72	dsmr_consumption	0020_quarter_hour_peaks	2023-02-24 12:59:21.562336+01
73	dsmr_consumption	0021_schedule_quarter_hour_peaks_calculation	2023-02-24 12:59:21.573065+01
74	dsmr_datalogger	0001_squashed_0005_optional_gas_readings	2023-02-24 12:59:21.650345+01
75	dsmr_datalogger	0002_meta_names	2023-02-24 12:59:21.655256+01
76	dsmr_datalogger	0003_telegram_checksum	2023-02-24 12:59:21.659389+01
77	dsmr_datalogger	0004_phase_currently_delivered	2023-02-24 12:59:21.668177+01
78	dsmr_datalogger	0005_verify_telegram_crc_setting	2023-02-24 12:59:21.672852+01
79	dsmr_datalogger	0006_dsmr_firmware_v5	2023-02-24 12:59:21.68061+01
80	dsmr_datalogger	0007_dsmrreading_timestamp_index	2023-02-24 12:59:21.693348+01
81	dsmr_datalogger	0008_dsmrreading_help_text	2023-02-24 12:59:21.71322+01
82	dsmr_datalogger	0009_retention_settings	2023-02-24 12:59:21.728133+01
83	dsmr_datalogger	0010_phases_currently_returned	2023-02-24 12:59:21.73811+01
84	dsmr_datalogger	0011_raw_telegram_insight	2023-02-24 12:59:21.747633+01
85	dsmr_datalogger	0012_track_phase_voltages	2023-02-24 12:59:21.75597+01
86	dsmr_datalogger	0013_remove_datalogger_track_settings	2023-02-24 12:59:21.761132+01
87	dsmr_datalogger	0014_remove_optional_crc_check	2023-02-24 12:59:21.764553+01
88	dsmr_datalogger	0015_datalogger_foreign_countries	2023-02-24 12:59:21.768565+01
89	dsmr_datalogger	0016_process_sleep	2023-02-24 12:59:21.782678+01
90	dsmr_datalogger	0017_log_telegrams	2023-02-24 12:59:21.797642+01
91	dsmr_datalogger	0018_meterstatistics_no_autonow	2023-02-24 12:59:21.803047+01
92	dsmr_datalogger	0019_verbose_field_translations	2023-02-24 12:59:21.806812+01
93	dsmr_datalogger	0020_track_power_current	2023-02-24 12:59:21.815459+01
94	dsmr_datalogger	0021_schedule_retention_data_rotation	2023-02-24 12:59:21.828008+01
95	dsmr_datalogger	0022_three_month_retention	2023-02-24 12:59:21.832429+01
96	dsmr_datalogger	0023_network_socket_datalogger	2023-02-24 12:59:21.843792+01
97	dsmr_datalogger	0024_enable_retention_by_default	2023-02-24 12:59:21.851013+01
98	dsmr_datalogger	0025_datalogger_mandatory_sleep_update	2023-02-24 12:59:21.865388+01
99	dsmr_datalogger	0026_datalogger_restart_required	2023-02-24 12:59:21.87059+01
100	dsmr_datalogger	0027_meter_statistics_change_log	2023-02-24 12:59:21.883374+01
101	dsmr_datalogger	0028_drop_legacy_telegram_logging	2023-02-24 12:59:21.888611+01
102	dsmr_datalogger	0029_default_retention_to_month	2023-02-24 12:59:21.892113+01
103	dsmr_datalogger	0030_override_telegram_timestamp	2023-02-24 12:59:21.89638+01
104	dsmr_datalogger	0031_meter_statistics_meta	2023-02-24 12:59:21.900198+01
105	dsmr_datalogger	0032_dsmr_extra_device_channel	2023-02-24 12:59:21.905946+01
106	dsmr_dropbox	0001_schedule_dropbox	2023-02-24 12:59:21.923564+01
107	dsmr_frontend	0001_initial	2023-02-24 12:59:21.935674+01
108	dsmr_frontend	0002_recent_history_weeks	2023-02-24 12:59:21.940947+01
109	dsmr_frontend	0003_drop_history_page	2023-02-24 12:59:21.944662+01
110	dsmr_frontend	0004_chart_colors	2023-02-24 12:59:21.958932+01
111	dsmr_frontend	0005_notifications	2023-02-24 12:59:21.975484+01
112	dsmr_frontend	0006_notifications_initial	2023-02-24 12:59:21.997152+01
113	dsmr_frontend	0007_merge_electricity_tariffs	2023-02-24 12:59:22.002938+01
114	dsmr_frontend	0008_merge_electricity_tariffs_notification	2023-02-24 12:59:22.018035+01
115	dsmr_frontend	0009_docs_no_reverse_match	2023-02-24 12:59:22.031625+01
116	dsmr_frontend	0010_drop_reverse_dashboard_graphs_setting	2023-02-24 12:59:22.036726+01
117	dsmr_frontend	0011_phase_currently_delivered	2023-02-24 12:59:22.045794+01
118	dsmr_frontend	0012_frontendsettings_dashboard_graph_width	2023-02-24 12:59:22.050246+01
119	dsmr_frontend	0013_echart_graphs_message	2023-02-24 12:59:22.063844+01
120	dsmr_frontend	0014_phases_currently_returned	2023-02-24 12:59:22.078982+01
121	dsmr_frontend	0015_notification_meta	2023-02-24 12:59:22.085074+01
122	dsmr_frontend	0016_v200_release	2023-02-24 12:59:22.098481+01
123	dsmr_frontend	0017_v201_release	2023-02-24 12:59:22.112642+01
124	dsmr_frontend	0018_v202_release	2023-02-24 12:59:22.127095+01
125	dsmr_frontend	0019_v210_release	2023-02-24 12:59:22.143001+01
126	dsmr_frontend	0020_v230_release	2023-02-24 12:59:22.156816+01
127	dsmr_frontend	0021_v260_release	2023-02-24 12:59:22.170734+01
128	dsmr_frontend	0022_v270_release	2023-02-24 12:59:22.236538+01
129	dsmr_frontend	0023_v290_release	2023-02-24 12:59:22.250127+01
130	dsmr_frontend	0024_v2100_release	2023-02-24 12:59:22.262592+01
131	dsmr_frontend	0025_increase_max_dashboard_graph_width	2023-02-24 12:59:22.267141+01
132	dsmr_frontend	0026_v2140_release	2023-02-24 12:59:22.281962+01
133	dsmr_frontend	0027_v215_release	2023-02-24 12:59:22.295188+01
134	dsmr_frontend	0028_v3_0_fix_upgrade_redirect	2023-02-24 12:59:22.309397+01
135	dsmr_frontend	0029_gas_graph_style	2023-02-24 12:59:22.314406+01
136	dsmr_frontend	0030_electricity_graph_style	2023-02-24 12:59:22.322847+01
137	dsmr_frontend	0031_tariff_names	2023-02-24 12:59:22.336356+01
138	dsmr_frontend	0032_v3_4_0_release	2023-02-24 12:59:22.350333+01
139	dsmr_frontend	0033_django_colorfield_update	2023-02-24 12:59:22.365893+01
140	dsmr_frontend	0034_mysql_timezone_support	2023-02-24 12:59:22.378604+01
141	dsmr_frontend	0035_graphs_range	2023-02-24 12:59:22.386705+01
142	dsmr_frontend	0036_graphs_zoom	2023-02-24 12:59:22.393481+01
143	dsmr_frontend	0037_v3_12_0_release	2023-02-24 12:59:22.405991+01
144	dsmr_frontend	0038_always_require_login	2023-02-24 12:59:22.411044+01
145	dsmr_frontend	0039_retention_headsup	2023-02-24 12:59:22.424408+01
146	dsmr_frontend	0040_v4_1_0_release	2023-02-24 12:59:22.438261+01
147	dsmr_frontend	0041_graph_ordering	2023-02-24 12:59:22.477329+01
148	dsmr_frontend	0042_v4_4_0_release	2023-02-24 12:59:22.491807+01
149	dsmr_frontend	0043_default_color_update_tariff_2	2023-02-24 12:59:22.516895+01
150	dsmr_frontend	0044_v4_20_0_release	2023-02-24 12:59:22.531385+01
151	dsmr_frontend	0045_frontendsettings_frontend_theme	2023-02-24 12:59:22.539479+01
152	dsmr_frontend	0046_gui_refresh_interval	2023-02-24 12:59:22.546955+01
153	dsmr_frontend	0047_tariff_name_update	2023-02-24 12:59:22.575766+01
154	dsmr_frontend	0048_electricity_peaks_graph	2023-02-24 12:59:22.592228+01
155	dsmr_frontend	0049_alter_notification_options	2023-02-24 12:59:22.596341+01
156	dsmr_influxdb	0001_influxdb_integration	2023-02-24 12:59:22.616975+01
157	dsmr_influxdb	0002_influxdb_optional_credentials	2023-02-24 12:59:22.623786+01
158	dsmr_influxdb	0003_influxdb_outgoing_measurements	2023-02-24 12:59:22.64256+01
159	dsmr_influxdb	0004_client_settings_update	2023-02-24 12:59:22.649565+01
160	dsmr_influxdb	0005_influxdb_v2_support	2023-02-24 12:59:22.683151+01
161	dsmr_influxdb	0006_influxdb_settings_field_size	2023-02-24 12:59:22.693258+01
162	dsmr_mindergas	0001_mindergas	2023-02-24 12:59:22.705806+01
163	dsmr_mindergas	0002_mindergas_notification	2023-02-24 12:59:22.721627+01
164	dsmr_mindergas	0003_mindergas_next_export_datetime	2023-02-24 12:59:22.735005+01
165	dsmr_mindergas	0004_mindergas_latest_sync	2023-02-24 12:59:22.743415+01
166	dsmr_mindergas	0005_schedule_mindergas_export	2023-02-24 12:59:22.767496+01
167	dsmr_mqtt	0001_mqtt_settings	2023-02-24 12:59:22.829224+01
168	dsmr_mqtt	0002_daytotalsmqttsettings	2023-02-24 12:59:22.863876+01
169	dsmr_mqtt	0003_splittopicmeterstatisticsmqttsettings	2023-02-24 12:59:22.882785+01
170	dsmr_mqtt	0004_phases_currently_returned	2023-02-24 12:59:22.889791+01
171	dsmr_mqtt	0005_mqtt_use_local_timezone	2023-02-24 12:59:22.895875+01
172	dsmr_mqtt	0006_mqtt_refactoring	2023-02-24 12:59:22.933779+01
173	dsmr_mqtt	0007_mqtts	2023-02-24 12:59:22.941708+01
174	dsmr_mqtt	0008_mqtt_null_payload	2023-02-24 12:59:22.945985+01
175	dsmr_mqtt	0009_remove_optional_debug	2023-02-24 12:59:22.950782+01
176	dsmr_mqtt	0010_mqtt_gas_consumption	2023-02-24 12:59:22.983084+01
177	dsmr_mqtt	0011_mqtt_meta_description	2023-02-24 12:59:23.001217+01
178	dsmr_mqtt	0012_mqtt_voltage_defaults	2023-02-24 12:59:23.007325+01
179	dsmr_mqtt	0013_process_sleep	2023-02-24 12:59:23.026604+01
180	dsmr_mqtt	0014_mqtt_telegram_defaults	2023-02-24 12:59:23.032776+01
181	dsmr_mqtt	0015_continuous_client	2023-02-24 12:59:23.061129+01
182	dsmr_mqtt	0016_client_settings_update	2023-02-24 12:59:23.072177+01
183	dsmr_mqtt	0017_mqtt_keep_reconnecting	2023-02-24 12:59:23.07736+01
184	dsmr_mqtt	0018_mqtt_always_reconnect	2023-02-24 12:59:23.081666+01
185	dsmr_mqtt	0019_mqtt_current_period_totals	2023-02-24 12:59:23.114793+01
186	dsmr_mqtt	0020_drop_mqtt_qos_setting	2023-02-24 12:59:23.12172+01
187	dsmr_mqtt	0021_quarter_hour_peak_mqtt	2023-02-24 12:59:23.154918+01
188	dsmr_notification	0001_initial	2023-02-24 12:59:23.169077+01
189	dsmr_notification	0002_notificationsetting_next_notification	2023-02-24 12:59:23.174127+01
190	dsmr_notification	0003_notification_notification	2023-02-24 12:59:23.19299+01
191	dsmr_notification	0004_statusnotificationsetting	2023-02-24 12:59:23.231717+01
192	dsmr_notification	0005_notify_my_android_ended_support	2023-02-24 12:59:23.255996+01
193	dsmr_notification	0006_support_for_pushover	2023-02-24 12:59:23.30075+01
194	dsmr_notification	0007_support_for_telegram	2023-02-24 12:59:23.312103+01
195	dsmr_notification	0008_dummy_notification_provider	2023-02-24 12:59:23.316564+01
196	dsmr_pvoutput	0001_pvoutput_settings	2023-02-24 12:59:23.338558+01
197	dsmr_pvoutput	0002_pvoutput_latest_sync	2023-02-24 12:59:23.344295+01
198	dsmr_pvoutput	0003_schedule_pvoutput	2023-02-24 12:59:23.372547+01
199	dsmr_pvoutput	0004_pvoutput_setting_refactoring	2023-02-24 12:59:23.379766+01
200	dsmr_weather	0001_weather_models	2023-02-24 12:59:23.40699+01
201	dsmr_stats	0001_squashed_0016_drop_stats_settings	2023-02-24 12:59:23.568705+01
202	dsmr_stats	0002_regenerate_missing_gas_data	2023-02-24 12:59:23.622405+01
203	dsmr_stats	0003_hour_statistics_gas_default	2023-02-24 12:59:23.632644+01
204	dsmr_stats	0004_hour_statistics_gas_default_retroactive	2023-02-24 12:59:23.656819+01
205	dsmr_stats	0005_statistics_exportverbose_names	2023-02-24 12:59:23.688086+01
206	dsmr_stats	0006_min_max_temperature_statistics	2023-02-24 12:59:23.695945+01
207	dsmr_stats	0007_min_max_temperature_statistics_retroactive	2023-02-24 12:59:23.722152+01
208	dsmr_stats	0008_meta_names	2023-02-24 12:59:23.728978+01
209	dsmr_stats	0009_statistics_editable	2023-02-24 12:59:23.735655+01
210	dsmr_stats	0010_statistics_models_index	2023-02-24 12:59:23.745227+01
211	dsmr_stats	0011_note_model_index	2023-02-24 12:59:23.754919+01
212	dsmr_stats	0012_electricity_statistics	2023-02-24 12:59:23.769425+01
213	dsmr_stats	0013_all_time_low	2023-02-24 12:59:23.78649+01
214	dsmr_stats	0014_day_total_cost_index	2023-02-24 12:59:23.795849+01
215	dsmr_stats	0015_fixed_daily_cost	2023-02-24 12:59:23.802532+01
216	dsmr_stats	0016_day_statistics_reading_history	2023-02-24 12:59:23.83278+01
217	dsmr_stats	0017_day_statistics_reading_history_retroactive	2023-02-24 12:59:23.855165+01
218	dsmr_stats	0018_day_statistics_meter_position_timestamps	2023-02-24 12:59:23.874297+01
219	dsmr_stats	0019_day_statistics_meter_position_timestamps_retroactive	2023-02-24 12:59:23.895695+01
220	dsmr_stats	0020_day_statistics_fix_total_gas_consumption_retroactive	2023-02-24 12:59:23.918984+01
221	dsmr_weather	0002_meta	2023-02-24 12:59:23.927939+01
222	dsmr_weather	0003_next_sync_setting	2023-02-24 12:59:23.932416+01
223	dsmr_weather	0004_next_sync_setting_retroactive	2023-02-24 12:59:23.957315+01
224	dsmr_weather	0005_weather_refactor_scheduling	2023-02-24 12:59:23.959762+01
225	dsmr_weather	0006_schedule_weather_update	2023-02-24 12:59:24.046156+01
226	sessions	0001_initial	2023-02-24 12:59:24.072906+01
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.


--
-- Data for Name: dsmr_api_apisettings; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_api_apisettings (id, allow, auth_key) FROM stdin;
1	f	E4FJW2JWNKR3ZTI8Q0SNIR398G4YZR2DNYFJYTP0P8F7ZLGQGCJKUSV3H1J0OUXJ
\.


--
-- Data for Name: dsmr_backend_backendsettings; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_backend_backendsettings (id, language, automatic_update_checker, process_sleep, disable_electricity_returned_capability, disable_gas_capability, restart_required) FROM stdin;
1	nl	t	1.0	f	f	f
\.


--
-- Data for Name: dsmr_backend_emailsettings; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_backend_emailsettings (id, host, port, username, password, use_tls, use_ssl, email_to, email_from) FROM stdin;
1	\N	\N	\N	\N	f	f	\N	\N
\.


--
-- Data for Name: dsmr_backend_scheduledprocess; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_backend_scheduledprocess (id, name, module, planned, active, last_executed_at) FROM stdin;
5	Generate consumption data	dsmr_consumption.services.run	2023-02-24 12:59:21.30607+01	t	\N
6	Calculate quarter hour electricity peaks	dsmr_consumption.services.run_quarter_hour_peaks	2023-02-24 12:59:21.571673+01	t	\N
7	Retention data rotation	dsmr_datalogger.services.retention.run	2023-02-24 12:59:21.82659+01	t	\N
8	Dropbox export	dsmr_dropbox.services.run	2023-02-24 12:59:21.922334+01	f	\N
9	Upload gas meter position to MinderGas.nl	dsmr_mindergas.services.run	2023-02-24 12:59:22.761683+01	f	\N
10	PVOutput export	dsmr_pvoutput.services.run	2023-02-24 12:59:23.371558+01	f	\N
11	Weather update	dsmr_weather.services.run	2023-02-24 12:59:24.04215+01	f	\N
1	Automatic update checker	dsmr_backend.services.update_checker.run	2023-02-25 12:59:20.893023+01	t	\N
2	Generate day and hour statistics	dsmr_stats.services.run	2023-02-24 13:59:26.665717+01	t	2023-02-24 12:59:26.656116+01
3	Backup per email	dsmr_backup.services.email.run	2023-02-25 12:59:26.687151+01	f	2023-02-24 12:59:26.679132+01
4	Create daily backup	dsmr_backup.services.backup.run	2023-02-24 12:59:21.078125+01	t	2023-02-24 12:59:26.688708+01
\.


--
-- Data for Name: dsmr_backup_backupsettings; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_backup_backupsettings (id, daily_backup, backup_time, folder, compression_level, file_name, backup_interval_in_days) FROM stdin;
1	t	02:00:00	backups/	1	{prefix}-{database_vendor}-{backup_type}-{day_name}	1
\.


--
-- Data for Name: dsmr_backup_dropboxsettings; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_backup_dropboxsettings (id, one_time_authorization_code, refresh_token, serialized_auth_flow) FROM stdin;
1	\N	\N	\N
\.


--
-- Data for Name: dsmr_backup_emailbackupsettings; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_backup_emailbackupsettings (id, "interval") FROM stdin;
1	\N
\.


--
-- Data for Name: dsmr_consumption_consumptionsettings; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_consumption_consumptionsettings (id, electricity_grouping_type, gas_grouping_type) FROM stdin;
\.


--
-- Data for Name: dsmr_consumption_electricityconsumption; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_consumption_electricityconsumption (id, read_at, delivered_1, returned_1, delivered_2, returned_2, currently_delivered, currently_returned, phase_currently_delivered_l1, phase_currently_delivered_l2, phase_currently_delivered_l3, phase_currently_returned_l1, phase_currently_returned_l2, phase_currently_returned_l3, phase_voltage_l1, phase_voltage_l2, phase_voltage_l3, phase_power_current_l1, phase_power_current_l2, phase_power_current_l3) FROM stdin;
\.


--
-- Data for Name: dsmr_consumption_energysupplierprice; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_consumption_energysupplierprice (id, start, "end", electricity_delivered_1_price, electricity_delivered_2_price, gas_price, description, electricity_returned_1_price, electricity_returned_2_price, fixed_daily_cost) FROM stdin;
\.


--
-- Data for Name: dsmr_consumption_gasconsumption; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_consumption_gasconsumption (id, read_at, delivered, currently_delivered) FROM stdin;
\.


--
-- Data for Name: dsmr_consumption_quarterhourpeakelectricityconsumption; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_consumption_quarterhourpeakelectricityconsumption (id, read_at_start, read_at_end, average_delivered) FROM stdin;
\.


--
-- Data for Name: dsmr_datalogger_dataloggersettings; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_datalogger_dataloggersettings (id, serial_port, dsmr_version, process_sleep, input_method, network_socket_address, network_socket_port, restart_required, override_telegram_timestamp, dsmr_extra_device_channel) FROM stdin;
1	/dev/ttyUSB0	4	5.0	serial	\N	23	f	f	\N
\.


--
-- Data for Name: dsmr_datalogger_dsmrreading; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_datalogger_dsmrreading (id, "timestamp", electricity_delivered_1, electricity_returned_1, electricity_delivered_2, electricity_returned_2, electricity_currently_delivered, electricity_currently_returned, extra_device_timestamp, extra_device_delivered, processed, phase_currently_delivered_l1, phase_currently_delivered_l2, phase_currently_delivered_l3, phase_currently_returned_l1, phase_currently_returned_l2, phase_currently_returned_l3, phase_voltage_l1, phase_voltage_l2, phase_voltage_l3, phase_power_current_l1, phase_power_current_l2, phase_power_current_l3) FROM stdin;
\.


--
-- Data for Name: dsmr_datalogger_meterstatistics; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_datalogger_meterstatistics (id, "timestamp", electricity_tariff, power_failure_count, long_power_failure_count, voltage_sag_count_l1, voltage_sag_count_l2, voltage_sag_count_l3, voltage_swell_count_l1, voltage_swell_count_l2, voltage_swell_count_l3, rejected_telegrams, dsmr_version, latest_telegram) FROM stdin;
1	2023-02-24 12:59:21.616231+01	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N
\.


--
-- Data for Name: dsmr_datalogger_meterstatisticschange; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_datalogger_meterstatisticschange (id, created_at, field, old_value, new_value) FROM stdin;
\.


--
-- Data for Name: dsmr_datalogger_retentionsettings; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_datalogger_retentionsettings (id, data_retention_in_hours) FROM stdin;
\.


--
-- Data for Name: dsmr_frontend_frontendsettings; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_frontend_frontendsettings (id, electricity_delivered_alternate_color, electricity_delivered_color, electricity_returned_alternate_color, electricity_returned_color, gas_delivered_color, temperature_color, merge_electricity_tariffs, phase_delivered_l1_color, phase_delivered_l2_color, phase_delivered_l3_color, phase_returned_l1_color, phase_returned_l2_color, phase_returned_l3_color, gas_graph_style, electricity_graph_style, stack_electricity_graphs, tariff_1_delivered_name, tariff_1_returned_name, tariff_2_delivered_name, tariff_2_returned_name, live_graphs_hours_range, live_graphs_initial_zoom, always_require_login, frontend_theme, gui_refresh_interval) FROM stdin;
\.


--
-- Data for Name: dsmr_frontend_notification; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_frontend_notification (id, message, redirect_to, read) FROM stdin;
1	Welkom bij DSMR-reader! Controleer eerst de instellingen in de Configuratie-pagina!	admin:index	f
\.


--
-- Data for Name: dsmr_frontend_sortedgraph; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_frontend_sortedgraph (id, name, graph_type, sorting_order) FROM stdin;
1	Electricity	electricity	1
2	Phases	phases	2
3	Voltage	voltage	3
4	Power	power_current	4
5	Gas	gas	5
6	Weather	weather	6
7	Electricity quarter hour peaks	electricity-peaks	7
\.


--
-- Data for Name: dsmr_influxdb_influxdbintegrationsettings; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_influxdb_influxdbintegrationsettings (id, enabled, hostname, port, bucket, secure, formatting, api_token, organization) FROM stdin;
1	f	localhost	8086	dsmrreader_measurements	insecure	\n### [measurement_name]\n### DSMR-reader field 1 = InfluxDB field 1\n### DSMR-reader field 2 = InfluxDB field 2\n\n[electricity_live]\nelectricity_currently_delivered = currently_delivered\nelectricity_currently_returned = currently_returned\n\n[electricity_positions]\nelectricity_delivered_1 = delivered_1\nelectricity_returned_1 = returned_1\nelectricity_delivered_2 = delivered_2\nelectricity_returned_2 = returned_2\n\n[electricity_voltage]\nphase_voltage_l1 = phase_l1\nphase_voltage_l2 = phase_l2\nphase_voltage_l3 = phase_l3\n\n[electricity_phases]\nphase_currently_delivered_l1 = currently_delivered_l1\nphase_currently_delivered_l2 = currently_delivered_l2\nphase_currently_delivered_l3 = currently_delivered_l3\nphase_currently_returned_l1 = currently_returned_l1\nphase_currently_returned_l2 = currently_returned_l2\nphase_currently_returned_l3 = currently_returned_l3\n\n[electricity_power]\nphase_power_current_l1 = current_l1\nphase_power_current_l2 = current_l2\nphase_power_current_l3 = current_l3\n\n[gas_positions]\nextra_device_delivered = delivered\n		
\.


--
-- Data for Name: dsmr_influxdb_influxdbmeasurement; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_influxdb_influxdbmeasurement (id, "time", measurement_name, fields) FROM stdin;
\.


--
-- Data for Name: dsmr_mindergas_mindergassettings; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_mindergas_mindergassettings (id, export, auth_token) FROM stdin;
1	f	\N
\.


--
-- Data for Name: dsmr_mqtt_jsoncurrentperiodtotalsmqttsettings; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_mqtt_jsoncurrentperiodtotalsmqttsettings (id, enabled, topic, formatting) FROM stdin;
\.


--
-- Data for Name: dsmr_mqtt_jsondaytotalsmqttsettings; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_mqtt_jsondaytotalsmqttsettings (id, enabled, topic, formatting) FROM stdin;
\.


--
-- Data for Name: dsmr_mqtt_jsongasconsumptionmqttsettings; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_mqtt_jsongasconsumptionmqttsettings (id, enabled, topic, formatting) FROM stdin;
\.


--
-- Data for Name: dsmr_mqtt_jsonquarterhourpeakelectricityconsumptionmqttsettings; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_mqtt_jsonquarterhourpeakelectricityconsumptionmqttsettings (id, enabled, topic, formatting) FROM stdin;
\.


--
-- Data for Name: dsmr_mqtt_jsontelegrammqttsettings; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_mqtt_jsontelegrammqttsettings (id, enabled, topic, formatting, use_local_timezone) FROM stdin;
\.


--
-- Data for Name: dsmr_mqtt_message; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_mqtt_message (id, topic, payload) FROM stdin;
\.


--
-- Data for Name: dsmr_mqtt_mqttbrokersettings; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_mqtt_mqttbrokersettings (id, hostname, port, username, password, client_id, restart_required, secure, enabled) FROM stdin;
1	localhost	1883	\N	\N	DSMR-reader	f	0	f
\.


--
-- Data for Name: dsmr_mqtt_rawtelegrammqttsettings; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_mqtt_rawtelegrammqttsettings (id, enabled, topic) FROM stdin;
\.


--
-- Data for Name: dsmr_mqtt_splittopiccurrentperiodtotalsmqttsettings; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_mqtt_splittopiccurrentperiodtotalsmqttsettings (id, enabled, formatting) FROM stdin;
\.


--
-- Data for Name: dsmr_mqtt_splittopicdaytotalsmqttsettings; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_mqtt_splittopicdaytotalsmqttsettings (id, enabled, formatting) FROM stdin;
\.


--
-- Data for Name: dsmr_mqtt_splittopicgasconsumptionmqttsettings; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_mqtt_splittopicgasconsumptionmqttsettings (id, enabled, formatting) FROM stdin;
\.


--
-- Data for Name: dsmr_mqtt_splittopicmeterstatisticsmqttsettings; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_mqtt_splittopicmeterstatisticsmqttsettings (id, enabled, formatting) FROM stdin;
\.


--
-- Data for Name: dsmr_mqtt_splittopicquarterhourpeakelectricityconsumptionmqf25c; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_mqtt_splittopicquarterhourpeakelectricityconsumptionmqf25c (id, enabled, formatting) FROM stdin;
\.


--
-- Data for Name: dsmr_mqtt_splittopictelegrammqttsettings; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_mqtt_splittopictelegrammqttsettings (id, enabled, formatting, use_local_timezone) FROM stdin;
\.


--
-- Data for Name: dsmr_notification_notificationsetting; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_notification_notificationsetting (id, notification_service, next_notification, prowl_api_key, pushover_api_key, pushover_user_key, telegram_api_key, telegram_chat_id) FROM stdin;
1	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: dsmr_notification_statusnotificationsetting; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_notification_statusnotificationsetting (id, next_check) FROM stdin;
\.


--
-- Data for Name: dsmr_pvoutput_pvoutputaddstatussettings; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_pvoutput_pvoutputaddstatussettings (id, export, upload_interval, upload_delay, processing_delay) FROM stdin;
1	f	5	0	\N
\.


--
-- Data for Name: dsmr_pvoutput_pvoutputapisettings; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_pvoutput_pvoutputapisettings (id, auth_token, system_identifier) FROM stdin;
1	\N	\N
\.


--
-- Data for Name: dsmr_stats_daystatistics; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_stats_daystatistics (id, day, total_cost, electricity1, electricity2, electricity1_returned, electricity2_returned, electricity1_cost, electricity2_cost, gas, gas_cost, average_temperature, highest_temperature, lowest_temperature, fixed_cost, electricity1_reading, electricity1_returned_reading, electricity2_reading, electricity2_returned_reading, gas_reading, electricity_reading_timestamp, gas_reading_timestamp) FROM stdin;
\.


--
-- Data for Name: dsmr_stats_electricitystatistics; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_stats_electricitystatistics (id, highest_usage_l1_timestamp, highest_usage_l2_timestamp, highest_usage_l3_timestamp, highest_return_l1_timestamp, highest_return_l2_timestamp, highest_return_l3_timestamp, highest_usage_l1_value, highest_usage_l2_value, highest_usage_l3_value, highest_return_l1_value, highest_return_l2_value, highest_return_l3_value, lowest_usage_l1_timestamp, lowest_usage_l1_value, lowest_usage_l2_timestamp, lowest_usage_l2_value, lowest_usage_l3_timestamp, lowest_usage_l3_value) FROM stdin;
\.


--
-- Data for Name: dsmr_stats_hourstatistics; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_stats_hourstatistics (id, hour_start, electricity1, electricity2, electricity1_returned, electricity2_returned, gas) FROM stdin;
\.


--
-- Data for Name: dsmr_stats_note; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_stats_note (id, day, description) FROM stdin;
\.


--
-- Data for Name: dsmr_weather_temperaturereading; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_weather_temperaturereading (id, read_at, degrees_celcius) FROM stdin;
\.


--
-- Data for Name: dsmr_weather_weathersettings; Type: TABLE DATA; Schema: public; Owner: dsmrreader
--

COPY public.dsmr_weather_weathersettings (id, track, buienradar_station) FROM stdin;
1	f	6260
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 30, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 2, true);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 53, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 226, true);


--
-- Name: dsmr_api_apisettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_api_apisettings_id_seq', 1, true);


--
-- Name: dsmr_backend_backendsettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_backend_backendsettings_id_seq', 1, false);


--
-- Name: dsmr_backend_emailsettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_backend_emailsettings_id_seq', 1, true);


--
-- Name: dsmr_backend_scheduledprocess_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_backend_scheduledprocess_id_seq', 11, true);


--
-- Name: dsmr_backup_backupsettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_backup_backupsettings_id_seq', 1, true);


--
-- Name: dsmr_backup_dropboxsettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_backup_dropboxsettings_id_seq', 1, true);


--
-- Name: dsmr_backup_emailbackupsettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_backup_emailbackupsettings_id_seq', 1, false);


--
-- Name: dsmr_consumption_consumptionsettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_consumption_consumptionsettings_id_seq', 1, false);


--
-- Name: dsmr_consumption_electricityconsumption_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_consumption_electricityconsumption_id_seq', 1, false);


--
-- Name: dsmr_consumption_energysupplierprice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_consumption_energysupplierprice_id_seq', 1, false);


--
-- Name: dsmr_consumption_gasconsumption_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_consumption_gasconsumption_id_seq', 1, false);


--
-- Name: dsmr_consumption_quarterhourpeakelectricityconsumption_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_consumption_quarterhourpeakelectricityconsumption_id_seq', 1, false);


--
-- Name: dsmr_datalogger_dataloggersettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_datalogger_dataloggersettings_id_seq', 1, false);


--
-- Name: dsmr_datalogger_dsmrreading_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_datalogger_dsmrreading_id_seq', 1, false);


--
-- Name: dsmr_datalogger_meterstatistics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_datalogger_meterstatistics_id_seq', 1, true);


--
-- Name: dsmr_datalogger_meterstatisticschange_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_datalogger_meterstatisticschange_id_seq', 1, false);


--
-- Name: dsmr_datalogger_retentionsettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_datalogger_retentionsettings_id_seq', 1, false);


--
-- Name: dsmr_frontend_frontendsettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_frontend_frontendsettings_id_seq', 1, false);


--
-- Name: dsmr_frontend_notification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_frontend_notification_id_seq', 1, true);


--
-- Name: dsmr_frontend_sortedgraph_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_frontend_sortedgraph_id_seq', 7, true);


--
-- Name: dsmr_influxdb_influxdbintegrationsettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_influxdb_influxdbintegrationsettings_id_seq', 1, true);


--
-- Name: dsmr_influxdb_influxdbmeasurement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_influxdb_influxdbmeasurement_id_seq', 1, false);


--
-- Name: dsmr_mindergas_mindergassettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_mindergas_mindergassettings_id_seq', 1, true);


--
-- Name: dsmr_mqtt_jsoncurrentperiodtotalsmqttsettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_mqtt_jsoncurrentperiodtotalsmqttsettings_id_seq', 1, false);


--
-- Name: dsmr_mqtt_jsondaytotalsmqttsettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_mqtt_jsondaytotalsmqttsettings_id_seq', 1, false);


--
-- Name: dsmr_mqtt_jsongasconsumptionmqttsettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_mqtt_jsongasconsumptionmqttsettings_id_seq', 1, false);


--
-- Name: dsmr_mqtt_jsonquarterhourpeakelectricityconsumptionmqtts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_mqtt_jsonquarterhourpeakelectricityconsumptionmqtts_id_seq', 1, false);


--
-- Name: dsmr_mqtt_jsontelegrammqttsettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_mqtt_jsontelegrammqttsettings_id_seq', 1, false);


--
-- Name: dsmr_mqtt_message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_mqtt_message_id_seq', 1, false);


--
-- Name: dsmr_mqtt_mqttbrokersettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_mqtt_mqttbrokersettings_id_seq', 1, true);


--
-- Name: dsmr_mqtt_rawtelegrammqttsettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_mqtt_rawtelegrammqttsettings_id_seq', 1, false);


--
-- Name: dsmr_mqtt_splittopiccurrentperiodtotalsmqttsettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_mqtt_splittopiccurrentperiodtotalsmqttsettings_id_seq', 1, false);


--
-- Name: dsmr_mqtt_splittopicdaytotalsmqttsettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_mqtt_splittopicdaytotalsmqttsettings_id_seq', 1, false);


--
-- Name: dsmr_mqtt_splittopicgasconsumptionmqttsettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_mqtt_splittopicgasconsumptionmqttsettings_id_seq', 1, false);


--
-- Name: dsmr_mqtt_splittopicmeterstatisticsmqttsettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_mqtt_splittopicmeterstatisticsmqttsettings_id_seq', 1, false);


--
-- Name: dsmr_mqtt_splittopicquarterhourpeakelectricityconsumptio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_mqtt_splittopicquarterhourpeakelectricityconsumptio_id_seq', 1, false);


--
-- Name: dsmr_mqtt_splittopictelegrammqttsettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_mqtt_splittopictelegrammqttsettings_id_seq', 1, false);


--
-- Name: dsmr_notification_notificationsetting_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_notification_notificationsetting_id_seq', 1, true);


--
-- Name: dsmr_notification_statusnotificationsetting_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_notification_statusnotificationsetting_id_seq', 1, false);


--
-- Name: dsmr_pvoutput_pvoutputaddstatussettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_pvoutput_pvoutputaddstatussettings_id_seq', 1, true);


--
-- Name: dsmr_pvoutput_pvoutputapisettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_pvoutput_pvoutputapisettings_id_seq', 1, true);


--
-- Name: dsmr_stats_daystatistics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_stats_daystatistics_id_seq', 1, false);


--
-- Name: dsmr_stats_electricitystatistics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_stats_electricitystatistics_id_seq', 1, false);


--
-- Name: dsmr_stats_hourstatistics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_stats_hourstatistics_id_seq', 1, false);


--
-- Name: dsmr_stats_note_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_stats_note_id_seq', 1, false);


--
-- Name: dsmr_weather_temperaturereading_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_weather_temperaturereading_id_seq', 1, false);


--
-- Name: dsmr_weather_weathersettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dsmrreader
--

SELECT pg_catalog.setval('public.dsmr_weather_weathersettings_id_seq', 1, true);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: dsmr_api_apisettings dsmr_api_apisettings_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_api_apisettings
    ADD CONSTRAINT dsmr_api_apisettings_pkey PRIMARY KEY (id);


--
-- Name: dsmr_backend_backendsettings dsmr_backend_backendsettings_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_backend_backendsettings
    ADD CONSTRAINT dsmr_backend_backendsettings_pkey PRIMARY KEY (id);


--
-- Name: dsmr_backend_emailsettings dsmr_backend_emailsettings_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_backend_emailsettings
    ADD CONSTRAINT dsmr_backend_emailsettings_pkey PRIMARY KEY (id);


--
-- Name: dsmr_backend_scheduledprocess dsmr_backend_scheduledprocess_module_key; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_backend_scheduledprocess
    ADD CONSTRAINT dsmr_backend_scheduledprocess_module_key UNIQUE (module);


--
-- Name: dsmr_backend_scheduledprocess dsmr_backend_scheduledprocess_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_backend_scheduledprocess
    ADD CONSTRAINT dsmr_backend_scheduledprocess_pkey PRIMARY KEY (id);


--
-- Name: dsmr_backup_backupsettings dsmr_backup_backupsettings_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_backup_backupsettings
    ADD CONSTRAINT dsmr_backup_backupsettings_pkey PRIMARY KEY (id);


--
-- Name: dsmr_backup_dropboxsettings dsmr_backup_dropboxsettings_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_backup_dropboxsettings
    ADD CONSTRAINT dsmr_backup_dropboxsettings_pkey PRIMARY KEY (id);


--
-- Name: dsmr_backup_emailbackupsettings dsmr_backup_emailbackupsettings_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_backup_emailbackupsettings
    ADD CONSTRAINT dsmr_backup_emailbackupsettings_pkey PRIMARY KEY (id);


--
-- Name: dsmr_consumption_consumptionsettings dsmr_consumption_consumptionsettings_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_consumption_consumptionsettings
    ADD CONSTRAINT dsmr_consumption_consumptionsettings_pkey PRIMARY KEY (id);


--
-- Name: dsmr_consumption_electricityconsumption dsmr_consumption_electricityconsumption_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_consumption_electricityconsumption
    ADD CONSTRAINT dsmr_consumption_electricityconsumption_pkey PRIMARY KEY (id);


--
-- Name: dsmr_consumption_electricityconsumption dsmr_consumption_electricityconsumption_read_at_key; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_consumption_electricityconsumption
    ADD CONSTRAINT dsmr_consumption_electricityconsumption_read_at_key UNIQUE (read_at);


--
-- Name: dsmr_consumption_energysupplierprice dsmr_consumption_energysupplierprice_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_consumption_energysupplierprice
    ADD CONSTRAINT dsmr_consumption_energysupplierprice_pkey PRIMARY KEY (id);


--
-- Name: dsmr_consumption_gasconsumption dsmr_consumption_gasconsumption_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_consumption_gasconsumption
    ADD CONSTRAINT dsmr_consumption_gasconsumption_pkey PRIMARY KEY (id);


--
-- Name: dsmr_consumption_gasconsumption dsmr_consumption_gasconsumption_read_at_key; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_consumption_gasconsumption
    ADD CONSTRAINT dsmr_consumption_gasconsumption_read_at_key UNIQUE (read_at);


--
-- Name: dsmr_consumption_quarterhourpeakelectricityconsumption dsmr_consumption_quarterhourpeakelectricityconsumption_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_consumption_quarterhourpeakelectricityconsumption
    ADD CONSTRAINT dsmr_consumption_quarterhourpeakelectricityconsumption_pkey PRIMARY KEY (id);


--
-- Name: dsmr_datalogger_dataloggersettings dsmr_datalogger_dataloggersettings_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_datalogger_dataloggersettings
    ADD CONSTRAINT dsmr_datalogger_dataloggersettings_pkey PRIMARY KEY (id);


--
-- Name: dsmr_datalogger_dsmrreading dsmr_datalogger_dsmrreading_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_datalogger_dsmrreading
    ADD CONSTRAINT dsmr_datalogger_dsmrreading_pkey PRIMARY KEY (id);


--
-- Name: dsmr_datalogger_meterstatistics dsmr_datalogger_meterstatistics_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_datalogger_meterstatistics
    ADD CONSTRAINT dsmr_datalogger_meterstatistics_pkey PRIMARY KEY (id);


--
-- Name: dsmr_datalogger_meterstatisticschange dsmr_datalogger_meterstatisticschange_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_datalogger_meterstatisticschange
    ADD CONSTRAINT dsmr_datalogger_meterstatisticschange_pkey PRIMARY KEY (id);


--
-- Name: dsmr_datalogger_retentionsettings dsmr_datalogger_retentionsettings_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_datalogger_retentionsettings
    ADD CONSTRAINT dsmr_datalogger_retentionsettings_pkey PRIMARY KEY (id);


--
-- Name: dsmr_frontend_frontendsettings dsmr_frontend_frontendsettings_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_frontend_frontendsettings
    ADD CONSTRAINT dsmr_frontend_frontendsettings_pkey PRIMARY KEY (id);


--
-- Name: dsmr_frontend_notification dsmr_frontend_notification_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_frontend_notification
    ADD CONSTRAINT dsmr_frontend_notification_pkey PRIMARY KEY (id);


--
-- Name: dsmr_frontend_sortedgraph dsmr_frontend_sortedgraph_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_frontend_sortedgraph
    ADD CONSTRAINT dsmr_frontend_sortedgraph_pkey PRIMARY KEY (id);


--
-- Name: dsmr_influxdb_influxdbintegrationsettings dsmr_influxdb_influxdbintegrationsettings_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_influxdb_influxdbintegrationsettings
    ADD CONSTRAINT dsmr_influxdb_influxdbintegrationsettings_pkey PRIMARY KEY (id);


--
-- Name: dsmr_influxdb_influxdbmeasurement dsmr_influxdb_influxdbmeasurement_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_influxdb_influxdbmeasurement
    ADD CONSTRAINT dsmr_influxdb_influxdbmeasurement_pkey PRIMARY KEY (id);


--
-- Name: dsmr_mindergas_mindergassettings dsmr_mindergas_mindergassettings_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_mindergas_mindergassettings
    ADD CONSTRAINT dsmr_mindergas_mindergassettings_pkey PRIMARY KEY (id);


--
-- Name: dsmr_mqtt_jsoncurrentperiodtotalsmqttsettings dsmr_mqtt_jsoncurrentperiodtotalsmqttsettings_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_mqtt_jsoncurrentperiodtotalsmqttsettings
    ADD CONSTRAINT dsmr_mqtt_jsoncurrentperiodtotalsmqttsettings_pkey PRIMARY KEY (id);


--
-- Name: dsmr_mqtt_jsondaytotalsmqttsettings dsmr_mqtt_jsondaytotalsmqttsettings_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_mqtt_jsondaytotalsmqttsettings
    ADD CONSTRAINT dsmr_mqtt_jsondaytotalsmqttsettings_pkey PRIMARY KEY (id);


--
-- Name: dsmr_mqtt_jsongasconsumptionmqttsettings dsmr_mqtt_jsongasconsumptionmqttsettings_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_mqtt_jsongasconsumptionmqttsettings
    ADD CONSTRAINT dsmr_mqtt_jsongasconsumptionmqttsettings_pkey PRIMARY KEY (id);


--
-- Name: dsmr_mqtt_jsonquarterhourpeakelectricityconsumptionmqttsettings dsmr_mqtt_jsonquarterhourpeakelectricityconsumptionmqttset_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_mqtt_jsonquarterhourpeakelectricityconsumptionmqttsettings
    ADD CONSTRAINT dsmr_mqtt_jsonquarterhourpeakelectricityconsumptionmqttset_pkey PRIMARY KEY (id);


--
-- Name: dsmr_mqtt_jsontelegrammqttsettings dsmr_mqtt_jsontelegrammqttsettings_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_mqtt_jsontelegrammqttsettings
    ADD CONSTRAINT dsmr_mqtt_jsontelegrammqttsettings_pkey PRIMARY KEY (id);


--
-- Name: dsmr_mqtt_message dsmr_mqtt_message_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_mqtt_message
    ADD CONSTRAINT dsmr_mqtt_message_pkey PRIMARY KEY (id);


--
-- Name: dsmr_mqtt_mqttbrokersettings dsmr_mqtt_mqttbrokersettings_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_mqtt_mqttbrokersettings
    ADD CONSTRAINT dsmr_mqtt_mqttbrokersettings_pkey PRIMARY KEY (id);


--
-- Name: dsmr_mqtt_rawtelegrammqttsettings dsmr_mqtt_rawtelegrammqttsettings_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_mqtt_rawtelegrammqttsettings
    ADD CONSTRAINT dsmr_mqtt_rawtelegrammqttsettings_pkey PRIMARY KEY (id);


--
-- Name: dsmr_mqtt_splittopiccurrentperiodtotalsmqttsettings dsmr_mqtt_splittopiccurrentperiodtotalsmqttsettings_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_mqtt_splittopiccurrentperiodtotalsmqttsettings
    ADD CONSTRAINT dsmr_mqtt_splittopiccurrentperiodtotalsmqttsettings_pkey PRIMARY KEY (id);


--
-- Name: dsmr_mqtt_splittopicdaytotalsmqttsettings dsmr_mqtt_splittopicdaytotalsmqttsettings_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_mqtt_splittopicdaytotalsmqttsettings
    ADD CONSTRAINT dsmr_mqtt_splittopicdaytotalsmqttsettings_pkey PRIMARY KEY (id);


--
-- Name: dsmr_mqtt_splittopicgasconsumptionmqttsettings dsmr_mqtt_splittopicgasconsumptionmqttsettings_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_mqtt_splittopicgasconsumptionmqttsettings
    ADD CONSTRAINT dsmr_mqtt_splittopicgasconsumptionmqttsettings_pkey PRIMARY KEY (id);


--
-- Name: dsmr_mqtt_splittopicmeterstatisticsmqttsettings dsmr_mqtt_splittopicmeterstatisticsmqttsettings_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_mqtt_splittopicmeterstatisticsmqttsettings
    ADD CONSTRAINT dsmr_mqtt_splittopicmeterstatisticsmqttsettings_pkey PRIMARY KEY (id);


--
-- Name: dsmr_mqtt_splittopicquarterhourpeakelectricityconsumptionmqf25c dsmr_mqtt_splittopicquarterhourpeakelectricityconsumptionm_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_mqtt_splittopicquarterhourpeakelectricityconsumptionmqf25c
    ADD CONSTRAINT dsmr_mqtt_splittopicquarterhourpeakelectricityconsumptionm_pkey PRIMARY KEY (id);


--
-- Name: dsmr_mqtt_splittopictelegrammqttsettings dsmr_mqtt_splittopictelegrammqttsettings_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_mqtt_splittopictelegrammqttsettings
    ADD CONSTRAINT dsmr_mqtt_splittopictelegrammqttsettings_pkey PRIMARY KEY (id);


--
-- Name: dsmr_notification_notificationsetting dsmr_notification_notificationsetting_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_notification_notificationsetting
    ADD CONSTRAINT dsmr_notification_notificationsetting_pkey PRIMARY KEY (id);


--
-- Name: dsmr_notification_statusnotificationsetting dsmr_notification_statusnotificationsetting_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_notification_statusnotificationsetting
    ADD CONSTRAINT dsmr_notification_statusnotificationsetting_pkey PRIMARY KEY (id);


--
-- Name: dsmr_pvoutput_pvoutputaddstatussettings dsmr_pvoutput_pvoutputaddstatussettings_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_pvoutput_pvoutputaddstatussettings
    ADD CONSTRAINT dsmr_pvoutput_pvoutputaddstatussettings_pkey PRIMARY KEY (id);


--
-- Name: dsmr_pvoutput_pvoutputapisettings dsmr_pvoutput_pvoutputapisettings_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_pvoutput_pvoutputapisettings
    ADD CONSTRAINT dsmr_pvoutput_pvoutputapisettings_pkey PRIMARY KEY (id);


--
-- Name: dsmr_stats_daystatistics dsmr_stats_daystatistics_day_key; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_stats_daystatistics
    ADD CONSTRAINT dsmr_stats_daystatistics_day_key UNIQUE (day);


--
-- Name: dsmr_stats_daystatistics dsmr_stats_daystatistics_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_stats_daystatistics
    ADD CONSTRAINT dsmr_stats_daystatistics_pkey PRIMARY KEY (id);


--
-- Name: dsmr_stats_electricitystatistics dsmr_stats_electricitystatistics_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_stats_electricitystatistics
    ADD CONSTRAINT dsmr_stats_electricitystatistics_pkey PRIMARY KEY (id);


--
-- Name: dsmr_stats_hourstatistics dsmr_stats_hourstatistics_hour_start_key; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_stats_hourstatistics
    ADD CONSTRAINT dsmr_stats_hourstatistics_hour_start_key UNIQUE (hour_start);


--
-- Name: dsmr_stats_hourstatistics dsmr_stats_hourstatistics_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_stats_hourstatistics
    ADD CONSTRAINT dsmr_stats_hourstatistics_pkey PRIMARY KEY (id);


--
-- Name: dsmr_stats_note dsmr_stats_note_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_stats_note
    ADD CONSTRAINT dsmr_stats_note_pkey PRIMARY KEY (id);


--
-- Name: dsmr_weather_temperaturereading dsmr_weather_temperaturereading_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_weather_temperaturereading
    ADD CONSTRAINT dsmr_weather_temperaturereading_pkey PRIMARY KEY (id);


--
-- Name: dsmr_weather_temperaturereading dsmr_weather_temperaturereading_read_at_key; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_weather_temperaturereading
    ADD CONSTRAINT dsmr_weather_temperaturereading_read_at_key UNIQUE (read_at);


--
-- Name: dsmr_weather_weathersettings dsmr_weather_weathersettings_pkey; Type: CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.dsmr_weather_weathersettings
    ADD CONSTRAINT dsmr_weather_weathersettings_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: dsmr_backend_scheduledprocess_active_5ef7244b; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX dsmr_backend_scheduledprocess_active_5ef7244b ON public.dsmr_backend_scheduledprocess USING btree (active);


--
-- Name: dsmr_backend_scheduledprocess_module_55cb894b_like; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX dsmr_backend_scheduledprocess_module_55cb894b_like ON public.dsmr_backend_scheduledprocess USING btree (module varchar_pattern_ops);


--
-- Name: dsmr_backend_scheduledprocess_planned_234388f1; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX dsmr_backend_scheduledprocess_planned_234388f1 ON public.dsmr_backend_scheduledprocess USING btree (planned);


--
-- Name: dsmr_consumption_electrici_currently_delivered_0f28e53a; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX dsmr_consumption_electrici_currently_delivered_0f28e53a ON public.dsmr_consumption_electricityconsumption USING btree (currently_delivered);


--
-- Name: dsmr_consumption_electrici_currently_returned_b7a910c8; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX dsmr_consumption_electrici_currently_returned_b7a910c8 ON public.dsmr_consumption_electricityconsumption USING btree (currently_returned);


--
-- Name: dsmr_consumption_electrici_phase_currently_delivered__0315221e; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX dsmr_consumption_electrici_phase_currently_delivered__0315221e ON public.dsmr_consumption_electricityconsumption USING btree (phase_currently_delivered_l2);


--
-- Name: dsmr_consumption_electrici_phase_currently_delivered__21a515a7; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX dsmr_consumption_electrici_phase_currently_delivered__21a515a7 ON public.dsmr_consumption_electricityconsumption USING btree (phase_currently_delivered_l3);


--
-- Name: dsmr_consumption_electrici_phase_currently_delivered__9998ce55; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX dsmr_consumption_electrici_phase_currently_delivered__9998ce55 ON public.dsmr_consumption_electricityconsumption USING btree (phase_currently_delivered_l1);


--
-- Name: dsmr_consumption_electrici_phase_power_current_l1_3d9fd70d; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX dsmr_consumption_electrici_phase_power_current_l1_3d9fd70d ON public.dsmr_consumption_electricityconsumption USING btree (phase_power_current_l1);


--
-- Name: dsmr_consumption_electrici_phase_voltage_l1_72e3c8f8; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX dsmr_consumption_electrici_phase_voltage_l1_72e3c8f8 ON public.dsmr_consumption_electricityconsumption USING btree (phase_voltage_l1);


--
-- Name: dsmr_consumption_electrici_phase_voltage_l2_917726c7; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX dsmr_consumption_electrici_phase_voltage_l2_917726c7 ON public.dsmr_consumption_electricityconsumption USING btree (phase_voltage_l2);


--
-- Name: dsmr_consumption_electrici_phase_voltage_l3_1a9d7c37; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX dsmr_consumption_electrici_phase_voltage_l3_1a9d7c37 ON public.dsmr_consumption_electricityconsumption USING btree (phase_voltage_l3);


--
-- Name: dsmr_consumption_energysupplierprice_end_1b6d8f8d; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX dsmr_consumption_energysupplierprice_end_1b6d8f8d ON public.dsmr_consumption_energysupplierprice USING btree ("end");


--
-- Name: dsmr_consumption_energysupplierprice_start_3f56c4ff; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX dsmr_consumption_energysupplierprice_start_3f56c4ff ON public.dsmr_consumption_energysupplierprice USING btree (start);


--
-- Name: dsmr_consumption_quarterho_average_delivered_234f8061; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX dsmr_consumption_quarterho_average_delivered_234f8061 ON public.dsmr_consumption_quarterhourpeakelectricityconsumption USING btree (average_delivered);


--
-- Name: dsmr_consumption_quarterho_read_at_start_e15ff2ff; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX dsmr_consumption_quarterho_read_at_start_e15ff2ff ON public.dsmr_consumption_quarterhourpeakelectricityconsumption USING btree (read_at_start);


--
-- Name: dsmr_datalogger_dsmrreading_processed_add8a852; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX dsmr_datalogger_dsmrreading_processed_add8a852 ON public.dsmr_datalogger_dsmrreading USING btree (processed);


--
-- Name: dsmr_datalogger_dsmrreading_timestamp_1f7020d1; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX dsmr_datalogger_dsmrreading_timestamp_1f7020d1 ON public.dsmr_datalogger_dsmrreading USING btree ("timestamp");


--
-- Name: dsmr_frontend_sortedgraph_sorting_order_7a883a44; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX dsmr_frontend_sortedgraph_sorting_order_7a883a44 ON public.dsmr_frontend_sortedgraph USING btree (sorting_order);


--
-- Name: dsmr_stats_daystatistics_total_cost_c898d987; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX dsmr_stats_daystatistics_total_cost_c898d987 ON public.dsmr_stats_daystatistics USING btree (total_cost);


--
-- Name: dsmr_stats_note_day_83d05681; Type: INDEX; Schema: public; Owner: dsmrreader
--

CREATE INDEX dsmr_stats_note_day_83d05681 ON public.dsmr_stats_note USING btree (day);


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: dsmrreader
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

